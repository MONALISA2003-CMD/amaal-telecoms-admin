# Amaal Telecoms — Full Project Audit

## Audit date
2026-08-27

## Current scope
This audit covers the existing Amaal Telecoms Business Admin / Render backend project after the Receiving → Batch integration hardening. The project remains a cumulative build; no rebuild or database replacement was performed.

## Current architecture
- Business Admin is a frontend/business-management layer.
- Render remains the existing business engine/backend.
- PostgreSQL remains the authoritative business data source.
- The Technical Console remains an existing business/technical authority and was not replaced.
- Public catalogue access remains separated from private operational inventory data.

## Database safety
- No PostgreSQL connection was made during this working-session audit.
- No reset, truncate, drop, recreation, destructive reseed or replacement was performed.
- Database changes are additive and repeat-safe.
- Existing historical records are preserved.
- Receiving reversal now preserves serialized-unit and batch history instead of deleting the physical-unit record.

## Receiving and batch integration completed
- Purchase-order goods receipts now create an `inventory_batches` record for each received purchase-order line.
- Batch records retain purchase order, purchase order line, goods receipt and supplier provenance.
- Batch records retain accepted and rejected quantities.
- Serialized units created by purchase receiving are linked directly to their receiving batch.
- Legacy stock-receipt ledger rows are linked to the same batch for compatibility.
- Goods-receipt detail now exposes batch number and serialized-unit count to authorized administrators.
- Accepted quantity, rather than rejected quantity, enters inventory balances.
- Purchase-order received quantity advances by accepted quantity.
- Serialized receiving requires whole units and exactly one identifier record per accepted unit.
- Duplicate identifier protection checks serial, IMEI 1, IMEI 2, barcode and QR values across all identifier fields.
- Batch numbers are protected from collision.
- Receipt cancellation marks the associated batch Cancelled and serialized units Voided instead of deleting their historical records.
- Voided units cannot be manually selected as a normal status.

## Business Admin receiving experience
- Purchase-order receiving is now a structured operator workflow rather than a JSON-only form.
- Staff select the receiving location and enter supplier delivery information.
- Each outstanding purchase-order line shows product, SKU, tracking type, outstanding quantity, received quantity, rejected quantity, unit cost and batch number.
- Serialized lines accept one physical identifier per line or CSV-style records with serial/IMEI/barcode/QR fields.
- Real browser camera access is used when supported.
- Rear-camera preference is requested on mobile.
- BarcodeDetector is used for real QR/barcode detection when supported.
- HTTPS, camera permission, unsupported-browser and unavailable-camera fallbacks are handled.
- Manual entry remains available when camera scanning is unavailable.

## Serialized inventory status
The serialized inventory foundation remains intact:
- `inventory_batches` exists.
- `serialized_units` exists.
- Product → variant → physical unit remains the core model.
- Batch linkage exists on serialized units.
- Barcode and QR storage exists.
- Manual entry, paste list, CSV and camera scanning remain available.
- Inventory unit audit passes.

## Cross-module integrity
Current static cross-module audit:
- Frontend API references: 104
- Backend routes: 564
- Unmatched frontend routes: 0
- Connected cross-module checks: 18/18

Relevant relationships include:
- Purchasing → Inventory
- Products → Inventory
- Orders → Inventory
- Orders → Sales
- Sales → Finance
- Customers → Sales/Orders/Credit
- Service → Customers/Orders/Inventory
- Website → Products
- Reports → Sales/Finance/Credit/Delivery

## Full-project verification performed
- Render preflight: PASS
- Receiving/batch audit: PASS — 15/15 checks
- Serialized inventory audit: PASS — 16/16 checks
- Cross-module audit: PASS — 104 frontend API references, 564 backend routes, 0 unmatched frontend routes, 18/18 cross-module checks connected
- JavaScript syntax checks: PASS for all top-level JavaScript source files checked
- Production dependency/build verification: NOT COMPLETED in this extracted environment because dependencies/node_modules are unavailable; no false build-pass claim is made.
- Database execution test: NOT RUN because DATABASE_URL is not configured in this environment and production data must not be touched without a controlled staging connection.
- Deployment readiness remains Critical in this environment because `DATABASE_URL` and `pg_dump` are unavailable; this is an environment/readiness limitation, not a database reset or application data change.

## Documentation cleanup
Redundant historical Markdown files were removed from the project root after their useful information was consolidated into the current audit/continuation documents:
- `CATALOGUE_MANAGEMENT_BUILD.md`
- `PLAN_UPDATE_NOTES.md`
- `PRODUCT_ADMIN_README.md`
- `SETUP_FIX.md`
- `VERCEL_BUILD_NOTES.md`
- `apps/business-admin/VERCEL_BUILD_NOTES.md`

`Amaal_plan.md` was deliberately preserved as requested.

## Exact-unit order assignment completed
- Added authorized available-unit lookup scoped to order, line, variant and location.
- Added identifier search for IMEI 1, IMEI 2, serial, barcode and QR.
- Added transactional exact-unit assignment with row locking and duplicate-safe handling.
- Assigned units move to `Reserved` and are released back to `In Stock` when an eligible order is unassigned or cancelled.
- Fulfilment accepts the assigned `Reserved` unit and changes the same physical unit to `Sold`.
- Business Admin now provides searchable assignment, real camera scanning and unassignment.
- Existing `order_serial_units.serialized_unit_id UNIQUE` protection was reused; no database migration was required.

## Verification after exact-unit order assignment
- Order serial assignment audit: PASS — 20/20.
- Render preflight: PASS.
- Cross-module audit: PASS — 104 frontend API references, 568 backend routes, 0 unmatched routes, 18/18 connected.
- Receiving/batch audit: PASS — 15/15.
- Serialized inventory audit: PASS — 16/16.
- Warehouse transfer audit: PASS — 15/15.
- JavaScript syntax: PASS for all top-level JavaScript files checked.
- Destructive database-operation scan: PASS.
- Live PostgreSQL execution: NOT RUN; no production database was contacted.
- Full production frontend build: NOT VERIFIED because dependencies are unavailable in the extracted environment.

## Remaining high-priority work
1. Make physical-unit history/status transitions authoritative across all business workflows.
2. Reconcile exact-unit assignment with picking, dispatch and delivery.
3. Complete IMEI/serial lookup across returns, warranty and service.
4. Audit Reports/BI field contracts and real-data presentation.
5. Run controlled staging/production verification once deployment dependencies and database access are available.
3. Harden serialized-unit history and status-transition rules across every business workflow.
4. Complete return/warranty/service physical-unit traceability.
5. Audit Reports/BI field contracts and unused live datasets.
6. Run controlled staging end-to-end tests with real non-production data.
7. Run the final Vercel production build and deployment smoke test.

## Non-negotiable constraints for future work
- Never reset PostgreSQL.
- Never truncate business tables.
- Never delete historical transactions to simplify development.
- Never create a second competing business database.
- Never expose IMEI, serial, supplier, purchase cost, warehouse or internal inventory information through the public catalogue.
- Never fabricate inventory, sales, finance or live-business values.
- Prefer archive/deactivate/reverse workflows over destructive deletion.


## Warehouse Transfer Audit — 27 Aug 2026

Warehouse transfer hardening was completed without database access or destructive operations.

- Transfer schema preserved.
- Serialized transfers require exact physical-unit selection.
- A transfer must be approved before shipping.
- Duplicate identifiers are prevented across the whole transfer, not only within one line.
- Source location and `In Stock` state are revalidated at ship time.
- Serialized units enter `Transferred` with no destination location while in transit.
- Destination receiving restores the same physical units; missing units are rejected rather than created.
- Business Admin provides search/selection and real camera scanning fallback.
- Transfer lifecycle controls expose Approve, Ship and Receive according to permissions.
- Transfer detail endpoint added.
- Static transfer audit: PASS.

Production database transaction execution and a full Next.js production build were not run in this environment.


## Physical Unit & Status Engine — 27 Aug 2026

### Lifecycle integrity
- Added `serialized_unit_status_history` as an additive physical-unit lifecycle ledger.
- Every new serialized unit and every later status/location change is captured by a database trigger.
- Existing units receive a historical baseline through a repeat-safe, non-destructive migration.
- Database transition enforcement prevents invalid status jumps independently of frontend controls.
- Voided units are terminal.
- Manual Business Admin status changes are limited to operational exception transitions; order/sale/transfer/return/receiving workflows remain authoritative for their controlled states.

### Traceability
The physical-unit history API now exposes:
- Unit and current location.
- Batch.
- Lifecycle timeline.
- Inventory movement context.
- Order assignments.
- Sales.
- Returns.
- Warranty claims.

### Fulfilment compatibility
Delivery completion now accepts a serialized unit in `Reserved` state when that exact unit is assigned to the order. This closes a prior mismatch where delivery expected `In Stock` and could leave an assigned physical unit incorrectly reserved.

### Verification
- Serialized status/history audit: PASS — 14/14.
- Receiving/batch audit: PASS — 15/15.
- Serialized inventory audit: PASS — 16/16.
- Warehouse transfer audit: PASS — 15/15.
- Order serial assignment audit: PASS — 20/20.
- Cross-module audit: PASS — 18/18; 0 unmatched frontend routes.
- Render preflight: PASS.
- JavaScript syntax: PASS — 32 root JavaScript files.
- Destructive database-operation review: no destructive serialized-unit operation introduced by this change.
- Production PostgreSQL transaction: not run.
- Production Next.js build: not verified because dependencies are unavailable in the extracted environment.

### Documentation hygiene
The project continues to retain `Amaal_plan.md`. Redundant historical Markdown files previously identified were removed; current operational documentation is maintained through the plan, continuation, audit and cross-module documents.


## 27 Aug 2026 — Fulfilment / Delivery Reconciliation Audit

The delivery workflow was audited against the serialized physical-unit model. Delivery shipments now retain explicit links to the exact `serialized_units` assigned to the order. Shipment creation rejects incomplete serialized assignments; progression revalidates Reserved state; delivery completion requires the complete exact-unit set and atomically transitions those units to Sold. Order dispatch also requires complete serialized assignment, and active delivery blocks accidental unassignment. Existing shipments are backfilled additively.

**Result: 14/14 PASS** (`fulfilment-delivery-audit.js`).

No destructive database operation was performed and no production PostgreSQL write was executed.


## Current project-wide verification — 27 Aug 2026

After the fulfilment/delivery work, the serialized-inventory regression chain was re-run:
- Fulfilment/delivery reconciliation: **14/14 PASS**.
- Serialized status/history: **14/14 PASS**.
- Exact order unit assignment: **20/20 PASS**.
- Warehouse transfers: **PASS**.
- Receiving/batch: **PASS**.
- Serialized inventory: **PASS**.
- Cross-module: **18/18 connected**, **0 unmatched frontend API references**.
- Render preflight: **PASS**.
- Destructive-operation scan: no active destructive serialized/delivery operation found.

Environment limitations remain: `DATABASE_URL` is not configured and `pg_dump` is unavailable in this working environment, so no live PostgreSQL transaction, production backup drill, or production restore was executed. The production Next.js/TypeScript build also remains unverified because frontend dependencies are unavailable. These are explicitly not reported as passes.


## Phase 2 — Neon schema reconciliation (27 Aug 2026)

The earlier audit statement that the live Neon schema had unrepresented business columns was re-checked directly against the current live database and current project SQL. The specific previously cited differences were **not confirmed**. In particular, the live database does not currently contain the previously cited `sales.created_by`, `refund_transactions.reason`, `customer_groups.updated_by`, `product_categories.updated_by`, `users.website`, or `goods_receipts.goods_receipt_id` columns.

The live database currently reports **201 public tables**, **551 indexes**, **2 user-defined triggers**, and **41 public functions** (including extension functions). The two serialized-unit triggers are present and correspond to the repository implementation.

No production database migration was required for this reconciliation pass. No database reset, truncate, destructive reseed, or business-data modification was performed.

A source-side `schema-reconciliation-audit.js` check was added for future deployments. It validates the critical business schema baseline when `DATABASE_URL` is available. In the present build environment the dependency installation is unavailable, so the new live connection check is marked unverified locally; the Neon checks above were performed directly against the live database.


## Phase 3 — Application-Side Serialized Unit Lifecycle Hardening (2026-08-27)

The serialized-unit workflow was hardened without changing the live Neon schema or business data. A shared `serialized-unit-lifecycle.js` guard now centralizes application-side transitions for order reservation/unassignment, fulfilment/delivery sale transitions, direct POS sale transitions, and manual status changes. Each transition locks the physical unit inside the caller transaction, validates the existing lifecycle, sets the authenticated actor context, updates the unit, and enriches the lifecycle-history row created by the existing PostgreSQL trigger. PostgreSQL remains the final status-transition enforcement layer.

No database reset, truncation, destructive migration, or business-data deletion was performed.

## Phase 3 safer-route verification — 2026-08-27

The serialized physical-unit lifecycle was hardened at the Render application transaction layer without changing Neon.

### Centralized transition coverage
- Orders: exact-unit reservation, release, fulfillment/sale
- Sales/POS: direct serialized sale
- Delivery: delivery completion to Sold
- Inventory: manual status transitions
- Returns: restock transition to Returned
- Warranty: Service entry, restore, resolution/collection
- Purchasing: goods-receipt reversal to Voided
- Stock transfers: ship to Transferred and receive to In Stock
- Stocktakes: Lost / In Stock reconciliation
- Inventory incidents: Damaged / Lost / Found / Returned

### Safety properties
- Physical unit is row-locked with `FOR UPDATE` before transition.
- Invalid status transitions are rejected by the centralized transition map.
- Existing PostgreSQL lifecycle enforcement remains intact.
- No database reset, truncate, destructive migration, or production-data modification was performed.
- Direct application-side serialized-unit status updates outside the centralized helper were removed from operational modules; the remaining match is an audit-regex fixture/documentation script, not an operational write path.

### Verification
- All JavaScript files pass `node --check`.
- Static audit confirms the critical operational modules import the centralized lifecycle helper.
- Neon was not modified during this safer-route implementation.

### Limitation
Full integration tests against live Neon require the project's runtime dependencies and authenticated test fixtures; they were not fabricated or claimed as passed when unavailable.

## Phase 3 lifecycle verification — 2026-08-27

- Serialized status/history audit: 14/14 PASS.
- Exact order serial assignment audit: 20/20 PASS.
- Fulfilment/delivery reconciliation audit: 14/14 PASS.
- Inventory unit audit: PASS.
- Cross-module audit: 104 frontend API references, 568 backend routes, 0 unmatched; 18 connected checks, 0 review checks.

The audit scripts were updated where their assertions were checking for legacy direct SQL status updates instead of the centralized `transitionSerializedUnit` implementation. No Neon schema or business data was changed during this verification.

Live end-to-end authenticated transaction testing remains a deployment/runtime verification item and is not claimed as passed here.
