# Amaal Public Website System Design V1

## Purpose
This document defines the system design for the Amaal customer-facing public website while preserving the existing Amaal backend, database, and Business Admin Console.

## Non-negotiable architecture
- No database reset.
- No database recreation.
- No destructive migrations.
- No duplicate source of truth for products, prices, promotions, orders, customers, delivery, warranty, or repairs.
- The public website must not connect directly to PostgreSQL.
- Existing Business Admin remains the operational back office.

## Target architecture

```text
Customer Browser
      |
      v
Amaal Public Website (Next.js)
      |
      v
Public-safe API / Existing Backend
      |
      +--> Catalogue / Products / Brands / Categories
      +--> Promotions
      +--> Cart / Checkout / Orders
      +--> Customers / Account
      +--> Delivery / Tracking
      +--> Returns / Warranty / Repairs
      +--> Public Content / Enquiries
      |
      v
Existing PostgreSQL Database

Business Admin Console --------------------^
```

## Frontend boundary
The public application owns presentation, routing, customer interaction, SEO, responsive UX, loading/error/empty states, and API consumption. It does not own business truth.

## Backend boundary
The existing backend remains authoritative for product data, pricing, promotion validation, availability, orders, payments, customer records, delivery state, returns, warranty, repairs, and operational rules.

## Public API principles
1. Read-only public catalogue data must be explicitly filtered.
2. Customer-specific operations require authentication where applicable.
3. Sensitive internal fields must never be serialized to public responses.
4. Payment success must be verified server-side.
5. Backend validation remains authoritative.
6. API contracts should be additive/backward-compatible whenever possible.

## Data flow
### Product discovery
`Browser -> Public Web -> public catalogue API -> existing database`

### Checkout
`Browser -> Public Web -> backend checkout -> payment provider -> backend verification -> order state`

### Account
`Browser -> Public Web -> customer authentication/session -> customer APIs`

### Tracking
`Browser -> Public Web -> authenticated order/tracking API -> delivery/order state`

### After-sales
`Browser -> Public Web -> authenticated/service APIs -> warranty/repair/return state`

## Security
Never expose database credentials, JWT secrets, payment secrets, supplier costs, margins, internal notes, private operational data, or administrative permissions to the public frontend.

## Deployment
Use separate Vercel projects for the two frontends while keeping the same repository where appropriate:

- `amaal-public-web` -> `src/livefix/apps/public-web`
- existing Admin Console -> its existing root/project

The exact Vercel root must match the Git repository root. If the repository is created from inside `src/livefix`, the public root becomes `apps/public-web`.

## Environments
Public frontend should have only public configuration such as the backend API base URL. Secrets remain on the backend.

## Observability
Track customer-safe events such as page views, search, product views, add-to-cart, checkout initiation, order completion, tracking views, returns, warranty/service requests, and enquiry submission. Avoid unnecessary sensitive data collection.

## Performance
Use server rendering/caching where appropriate, optimized images, responsive images, pagination, efficient API calls, and lightweight client-side JavaScript.

## SEO
Indexable category/product/content routes should expose appropriate metadata, canonical URLs, sitemap/robots configuration, and structured data where the underlying data is authoritative.

## Current implementation state
Phase 23 contains the public-web application foundation and discovery layer. Remaining implementation must be driven by verified backend/API capability rather than invented contracts.

## Next system work
- verify authoritative product/variant response shape;
- verify search/filter/sort APIs;
- map cart and checkout contracts;
- map payment integration;
- map customer authentication;
- map orders/tracking;
- map promotions;
- map returns/warranty/repairs;
- map enquiries/leads;
- production build and integration verification.
