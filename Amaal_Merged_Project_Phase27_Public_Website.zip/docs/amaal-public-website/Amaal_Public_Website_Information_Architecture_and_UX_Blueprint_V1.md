# Amaal Public Website Information Architecture & UX Blueprint V1

**Status:** Proposed for approval  
**Product:** Amaal Public Website  
**Version:** V1.0  
**Date:** 29 August 2026

## 1. Executive Summary

Amaal is a premium, multi-category, multi-brand consumer electronics retailer serving everyday customers.

The public website must combine:

- brand building;
- product discovery and catalogue;
- online purchasing;
- enquiries and lead generation;
- customer self-service;
- delivery and order tracking;
- warranty;
- repairs/service;
- promotions and deals.

The five-second perception is:

> **Amaal is a premium, trusted and genuine consumer electronics retailer.**

The visual foundation is **Lightweight Premium Modern Luxury**. The UX must remain easy, commercial and approachable rather than allowing luxury styling to reduce findability.

## 2. Source of Truth

The supplied engineering handoff remains the primary source for project constraints. It states that the public website must consume approved public-safe data from the existing backend/database rather than create a competing business system, and prohibits destructive database changes, unnecessary backend replacement, duplicate sources of truth and unnecessary rewriting of working APIs. fileciteturn1file7L1579-L1661

Conceptually:

```text
BUSINESS ADMIN CONSOLE
        ↓
EXISTING BACKEND + DATABASE
        ↓
PUBLIC-SAFE DATA / APIs
        ↓
AMAAL PUBLIC WEBSITE
        ↓
CUSTOMER
```

The public site must not expose supplier costs, margins, private stock data, employee information, internal financial/operational data, secrets, admin permissions, private customer information or audit data. fileciteturn1file7L1598-L1626

## 3. UX Research Context

This blueprint combines:

1. Amaal-specific requirements from the engineering handoff.
2. The approved Amaal Design System V1.
3. Current ecommerce UX research.

Baymard's 2025 homepage/category benchmark found 58% of desktop and 67% of mobile ecommerce sites had mediocre-to-poor performance in this area. citeturn0search0turn0search1

Baymard's 2026 product-page benchmark reports only 48% of leading desktop ecommerce sites and 38% of mobile sites had decent-or-better product-page UX. citeturn0search2

**Amaal implication:** premium visual design must never reduce product findability, product clarity or checkout usability.

## 4. Primary Experience Model

```text
                 AMAAL
                   |
       +-----------+-----------+
       |           |           |
     BROWSE      SEARCH      CAMPAIGN
       |           |           |
   CATEGORY     RESULTS      DEAL
       |           |           |
       +-----------+-----------+
                   |
                PRODUCT
                   |
                  CART
                   |
               CHECKOUT
                   |
                PAYMENT
                   |
              CONFIRMATION
                   |
              ORDER TRACKING
                   |
                DELIVERY
                   |
             AFTER-SALES
```

This extends the handoff's intended discovery-to-support journey. fileciteturn1file3L779-L807

# 5. Information Architecture

## 5.1 Primary Sitemap

```text
HOME

SHOP
├── All Products
├── Categories
│   ├── Phones
│   ├── Tablets
│   ├── TVs
│   ├── Refrigeration
│   ├── Home Appliances
│   ├── Kitchen Appliances
│   ├── Office Electronics
│   └── Sound & Speakers
├── Brands
├── New Arrivals
├── Featured
└── Search

DEALS
├── All Deals
├── Promotions
└── Campaigns

PRODUCT
├── Product Detail
└── Related / Alternative Products

COMMERCE
├── Cart
├── Checkout
├── Payment
└── Order Confirmation

ACCOUNT
├── Sign In
├── Register
├── Profile
├── Addresses
├── Orders
├── Order Tracking
├── Saved Products
├── Returns
├── Warranty
└── Support

SERVICES
├── Delivery
├── Returns
├── Warranty
└── Repairs / Service

COMPANY
├── About Amaal
├── Contact
└── Help / FAQ

LEGAL
├── Privacy
├── Terms
└── Policies
```

This extends the handoff's proposed product map; the handoff explicitly says it is a proposal to prioritize after discussion, not an instruction to build everything immediately. fileciteturn1file1L318-L373

# 6. Global Navigation

## Desktop

Recommended primary navigation:

```text
AMAAL

Shop    Categories    Brands    Deals    Services

                         Search   Account   Bag
```

A broad **Shop/Categories** path should expose the full catalogue hierarchy. Research supports clear category access and visible parent categories rather than hiding the product hierarchy behind vague navigation. citeturn0search0turn0search3

## Mega Menu

Use a premium, lightweight mega menu:

```text
SHOP

PHONES & TABLETS       HOME
Phones                 Refrigerators
Smartphones            Washing Machines
Feature Phones         Air Conditioners
Tablets                Home Appliances

KITCHEN                ENTERTAINMENT
Cookers                TVs
Microwaves             Home Theatre
Blenders               Sound & Speakers

OFFICE                 DISCOVER
Laptops                New Arrivals
Monitors               Featured
Printers               Premium Picks
Office Electronics     Deals
```

Actual categories must come from the real catalogue. Parent categories should be clickable. Subcategories should be grouped into manageable chunks. Promotional content should not overwhelm navigation.

## Mobile

Mobile navigation should make **Shop/Categories** immediately understandable:

```text
AMAAL                         Search  Bag

Search products...

Shop
Categories
Brands
Deals
Services

Account
Help
```

A bottom action bar such as **Home | Shop | Search | Bag | Account** can be prototyped and tested, but should not be forced if it conflicts with Amaal's lightweight luxury direction. Baymard's current mobile research emphasizes a highly visible path to broad categories. citeturn0search8

# 7. Homepage UX

The homepage is the commercial and brand front door.

Recommended sequence:

```text
HEADER
↓
HERO
↓
TRUST / VALUE
↓
SHOP BY CATEGORY
↓
FEATURED PRODUCTS
↓
BRANDS
↓
THE AMAAL EDIT
↓
DEALS / CAMPAIGNS
↓
WHY AMAAL
↓
SERVICES / SUPPORT
↓
BRAND STORY
↓
FINAL CTA
↓
FOOTER
```

The handoff proposes a closely related structure and requires real public-safe product data and approved promotions. fileciteturn1file3L811-L854

## Hero

Objective: communicate **Premium + Electronics + Trust + Amaal** within seconds.

Concept:

```text
Technology,
beautifully chosen.

Discover phones, appliances,
entertainment and more.

[ Shop Now ]    [ Explore ]
```

Use one primary message and one primary CTA. Avoid a homepage dominated by promotional banners; current research shows overly prominent promotions can interfere with product discovery. citeturn0search0

## Trust / Value

Potential themes:

- Genuine products
- Trusted brands
- Secure shopping
- Delivery
- Warranty & support

Only substantiated claims should be published.

## Shop by Category

Use broad, visually recognizable destinations. The exact list must be generated from the actual catalogue.

## Featured Products

Use real backend data. Potential merchandising groups:

- New Arrivals
- Best Sellers
- Premium Picks
- Everyday Essentials

The handoff explicitly requires real public-safe backend data. fileciteturn1file3L833-L837

## The Amaal Edit

A curated merchandising layer can make Amaal feel like a retailer rather than a raw catalogue:

- New & Noteworthy
- Premium Picks
- Everyday Essentials
- Home Upgrade
- Entertainment
- Smart Living
- Work & Office

## Deals

Deals should feel premium, not noisy. Use restrained campaign treatments and approved promotion data.

# 8. Category Architecture

A category should expose its hierarchy clearly.

```text
Category
↓
Subcategories
↓
Product Listing
```

For an intermediary category page, prioritize subcategories near the top:

```text
Category title
Short introduction

SHOP BY TYPE

Subcategory 1  Subcategory 2  Subcategory 3  Subcategory 4

Featured products

All products
```

Baymard research recommends prioritizing subcategory navigation on intermediary pages rather than burying it beneath promotions. citeturn0search0

# 9. Product Listing / PLP

Recommended structure:

```text
Breadcrumbs

Category / Search Title
Description

Subcategories where relevant

[ Filter ] [ Sort ]

Applied Filters

X products

Product Grid
```

Required capabilities:

- category browsing;
- filtering;
- sorting;
- result count;
- applied-filter visibility;
- clear filters;
- pagination or efficient loading.

These are explicitly required by the handoff. fileciteturn1file0L56-L73

## Filtering

Universal candidates:

- Brand
- Price
- Availability
- Promotion

Category-specific attributes should be derived from actual product data. **Do not build fake filters.**

# 10. Search & Discovery

Search is a first-class capability and should be accessible from every major page.

Search should eventually support:

- products;
- brands;
- categories;
- model names/numbers;
- relevant content;
- typo tolerance where supported;
- synonyms where supported;
- useful autocomplete;
- persistent queries;
- no-result recovery.

Suggested autocomplete groups:

```text
PRODUCTS
Samsung Galaxy...
Samsung TV...

CATEGORIES
Samsung TVs
Phones

BRANDS
Samsung

CONTENT
Warranty
Delivery
Returns
```

Supporting non-product queries is particularly valuable because ecommerce/luxury UX research has observed users searching for returns, shipping and warranty information. citeturn0search11

Nielsen Norman Group likewise treats search, filters and routing pages as core product-finding mechanisms. citeturn0search4

# 11. Brand Architecture

Because Amaal is multi-brand, brand discovery is a first-class path.

## Brand directory

```text
ALL BRANDS

A
Apple
...

B
Bosch
...

L
LG
...

S
Samsung
Sony
...
```

The actual list must come from published backend catalogue data.

## Brand page

```text
Brand Hero
↓
Brand Introduction
↓
Featured Categories
↓
Featured Products
↓
All Products
```

# 12. Product Detail Page

The product page is the primary decision-making surface.

The handoff requires images, name, brand, price, promotion, public availability, variants, specifications, description, delivery, warranty, related products and add-to-cart. fileciteturn1file0L75-L95

Recommended hierarchy:

```text
Breadcrumbs

Brand
Product Name

Product Gallery

Price
Promotion
Availability

Configuration / Variants

[ Add to Bag ]

Delivery
Warranty
Trust

Description
Specifications
What's Included
Delivery Information
Warranty Information

Related / Alternative Products
```

## Images

Mobile should support:

- swipe gallery;
- high-resolution images;
- pinch-to-zoom;
- double-tap zoom.

Baymard's mobile research identifies image zoom as an important product-inspection capability. citeturn0search8

## Variants

Make choices explicit and availability visible:

```text
Storage
[ 128GB ] [ 256GB ] [ 512GB ]

Colour
[ Black ] [ Silver ]
```

Current product-page research recommends clear variant selection and visibility of availability. citeturn0search2

## Related products

Prefer:

- alternative products;
- complementary products;
- recently viewed, if supported.

Recommendations must be relevant. Baymard research finds users use cross-sells to discover alternatives, but irrelevant suggestions are commonly ignored. citeturn0search8

# 13. Cart

```text
YOUR BAG

Product
Variant
Quantity
Price

Subtotal
Delivery estimate
Promotion
Total

[ Checkout ]

Continue Shopping
```

The backend remains authoritative for price, promotions, availability and checkout validation. fileciteturn1file0L99-L119

A cart drawer is recommended for fast feedback after add-to-bag.

# 14. Checkout

Approved conceptual sequence:

```text
CUSTOMER INFORMATION
        ↓
DELIVERY
        ↓
PAYMENT
        ↓
REVIEW
        ↓
CONFIRM
```

This follows the engineering handoff. fileciteturn1file2L452-L470

Principles:

- mobile-first;
- concise;
- transparent totals;
- clear delivery information;
- clear progress;
- validation near fields;
- support path;
- preserve entered information where safe.

# 15. Payment

Payment must remain backend-controlled:

```text
Customer
↓
Amaal Website
↓
Backend
↓
Payment Provider
↓
Backend Verification
↓
Order State
↓
Confirmation
```

The frontend must never independently declare payment success and must not expose payment or webhook secrets. fileciteturn1file2L474-L502

Actual payment methods must be confirmed from the existing Amaal payment architecture and business requirements.

# 16. Order Confirmation & Tracking

Confirmation must immediately answer: **Did my order succeed?**

```text
ORDER CONFIRMED

Order #XXXX
Payment: Confirmed
Delivery: Status / Estimate

[ Track Order ]
[ View Order ]
```

Tracking can conceptually show:

```text
ORDER PLACED
↓
PAYMENT CONFIRMED
↓
PROCESSING
↓
DISPATCHED
↓
IN TRANSIT
↓
OUT FOR DELIVERY
↓
DELIVERED
```

Actual states must match the backend lifecycle.

# 17. Customer Account & Self-Service

Customer accounts must remain distinct from staff accounts. The handoff identifies registration, login, profile, addresses, orders, tracking, saved products, returns, warranty and support as potential capabilities. fileciteturn1file2L506-L525

Account dashboard:

```text
Hello, Customer

Recent Order
[ Track Order ]

Orders
Addresses
Saved Products
Returns
Warranty
Support
Profile
```

Priority self-service tasks:

1. Track an order
2. View order details
3. Check delivery
4. Check warranty
5. Start a return
6. Start a warranty claim
7. Start a service request
8. Manage profile
9. Manage addresses
10. Contact support

# 18. Returns, Warranty & Repairs

## Returns

```text
ORDER
↓
ELIGIBLE PRODUCT
↓
RETURN REQUEST
↓
REVIEW
↓
STATUS
```

## Warranty

```text
PRODUCT
↓
WARRANTY INFORMATION
↓
CLAIM
↓
STATUS
```

## Repairs / Service

```text
DEVICE
↓
ISSUE
↓
SERVICE REQUEST
↓
ASSESSMENT
↓
STATUS
```

These journeys are directly specified in the handoff; operational decisions remain the responsibility of the backend/business system. fileciteturn1file2L529-L575

# 19. Enquiries & Lead Generation

Not every customer should be forced into a purchase flow.

Provide enquiry paths for:

- product enquiries;
- unavailable products;
- service questions;
- general contact;
- approved business/bulk enquiries.

Example fallback:

```text
Can't find what you're looking for?

[ Ask Amaal ]
```

# 20. Services & Content

Public service/content pages should include, where supported:

- Delivery
- Returns
- Warranty
- Repairs / Service
- About
- Contact
- FAQ
- Privacy
- Terms
- Policies

The handoff explicitly calls for these content areas and recommends making content manageable without unnecessary code deployments where existing architecture supports it. fileciteturn1file2L579-L593

# 21. Footer

```text
AMAAL

SHOP
Categories
Brands
Deals
New Arrivals

CUSTOMER CARE
Help / FAQ
Delivery
Returns
Warranty
Repairs
Contact

ACCOUNT
Sign In
Orders
Track Order
Saved Products

ABOUT
About Amaal
Contact

LEGAL
Privacy
Terms
Policies

Approved social channels

© Amaal
```

# 22. URLs & SEO

Conceptual routes:

```text
/
/shop
/phones
/phones/smartphones
/brands/samsung
/deals
/search?q=samsung
/product/[slug]
/cart
/checkout
/account
/account/orders
/track-order
/services/warranty
/services/repairs
/about
/contact
/faq
```

Final routes must follow actual repository conventions.

Important pages should support title, meta description, canonical URL, Open Graph metadata, semantic headings, structured data, sitemap and robots configuration. These are explicit handoff requirements. fileciteturn1file3L597-L614

Google's current documentation supports careful product and product-variant structured data; product markup should reflect the actual page content and authoritative product data. citeturn0search10turn0search13

# 23. Mobile UX

Required responsive testing:

```text
Mobile: 360 / 375 / 390 / 412
Tablet: 768 / 820
Desktop: 1024 / 1280 / 1440 / 1920
```

Test:

- navigation;
- homepage;
- search;
- category/listing;
- filters;
- product gallery;
- product page;
- cart;
- checkout;
- account;
- tracking;
- services;
- footer.

The handoff explicitly says mobile should not simply be a compressed desktop layout. fileciteturn1file3L648-L673

# 24. Accessibility

Every public flow should provide:

- semantic HTML;
- keyboard navigation;
- visible focus;
- accessible labels;
- descriptive image alt text;
- meaningful heading hierarchy;
- sufficient contrast;
- accessible forms;
- adequate touch targets;
- reduced-motion support;
- state communication that does not rely only on colour.

# 25. Performance

Priorities:

- optimized responsive images;
- lazy loading where appropriate;
- efficient API requests;
- caching;
- pagination;
- minimal client-side JavaScript;
- skeleton loading;
- no unnecessary dependencies.

These priorities are explicitly identified in the handoff. fileciteturn1file3L618-L644

# 26. Data / API Boundary

Before implementation, verify whether the existing backend already exposes public-safe capabilities for:

| Requirement | Verify |
|---|---|
| Products | Published product listing |
| Categories | Public taxonomy |
| Brands | Published brands |
| Search | Search endpoint |
| Filters | Attribute metadata |
| Product detail | Public product endpoint |
| Availability | Public availability |
| Promotions | Approved promotions |
| Content | Public content |
| FAQ | Public FAQ |
| Cart | Cart operations |
| Checkout | Checkout operations |
| Payment | Existing payment architecture |
| Orders | Customer order access |
| Tracking | Order tracking |
| Account | Customer-safe auth |
| Returns | Return workflow |
| Warranty | Warranty workflow |
| Repairs | Service workflow |
| Enquiries | Lead/contact endpoint |

The handoff says to reuse existing public endpoints where possible and create only minimal safe additions where necessary. fileciteturn1file4L997-L1023

# 27. Frontend Feature Architecture

Conceptually:

```text
features/
├── products/
├── categories/
├── brands/
├── search/
├── promotions/
├── cart/
├── checkout/
├── orders/
├── account/
├── returns/
├── warranty/
├── service/
└── enquiries/
```

This follows the handoff's proposed feature organization while preserving the instruction to adapt to actual repository conventions. fileciteturn1file4L1027-L1069

# 28. Shared Components

Initial shared component foundation:

```text
Header
MobileNavigation
Footer

Button
IconButton
Input
SearchInput
Select
Checkbox
Radio
Badge
Tag

Modal
Drawer
Toast

Skeleton
LoadingState
EmptyState
ErrorState

Breadcrumbs
Pagination

ProductCard
CategoryCard
BrandCard
PromotionCard
PriceDisplay
QuantityControl
ProductGallery

SectionHeading
ContentContainer
```

Only create abstractions where repetition justifies them; the handoff explicitly warns against over-engineering. fileciteturn1file3L730-L775

# 29. Core Customer Journeys

## A — Standard purchase

```text
Home → Category → Listing → Product → Cart → Checkout → Delivery → Payment → Confirmation → Tracking → Delivery
```

## B — Search-led

```text
Home → Search → Suggestions → Results → Filter → Product → Cart → Checkout
```

## C — Brand-led

```text
Home → Brands → Brand → Category → Product → Cart
```

## D — Deal-led

```text
Home → Deals → Promotion → Listing → Product → Cart
```

## E — After-sales

```text
Account → Order → Product → Warranty / Return / Service → Request → Status
```

## F — Enquiry

```text
Search / Product / Contact → Ask Amaal → Enquiry → Confirmation → Follow-up
```

# 30. UX State Model

Every major flow must handle:

```text
Default
↓
Loading
↓
Success
↓
Empty
↓
Error
↓
Recovery
```

Examples include empty cart, no search results, unavailable variants, failed payment, order status delays and service-request errors.

# 31. Trust & Conversion Model

Amaal's conversion model should be:

```text
Confidence
+
Findability
+
Product clarity
+
Transparent price
+
Delivery clarity
+
Warranty/support
=
Purchase confidence
```

The site should not depend on aggressive discount tactics to convert.

# 32. Analytics

Core events should include:

```text
page_view
search_performed
category_viewed
product_viewed
filter_applied
product_variant_selected
add_to_cart
remove_from_cart
cart_viewed
checkout_started
checkout_step_completed
payment_started
order_completed
order_tracking_viewed
return_started
warranty_started
service_request_started
lead_submitted
```

Analytics must not expose sensitive customer data.

# 33. Risks & Mitigation

### Catalogue complexity
Use clear top-level taxonomy and category-specific filtering.

### Premium design reducing usability
Keep price, availability, variants and CTAs strongly prioritized.

### Backend gaps
Inspect APIs before implementation and add only minimal safe endpoints.

### Duplicate business logic
Keep the backend authoritative.

### Search quality
Treat search as a product capability, not just a field.

### Mobile complexity
Design mobile journeys independently.

### Promotion overload
Campaigns must support, not replace, product discovery.

### After-sales fragmentation
Connect orders, delivery, returns, warranty and service through the account experience.

# 34. Figma UX Planning Structure

The next Figma planning file/page structure should be:

```text
01 — Cover / Brand
02 — Design System
03 — Information Architecture
04 — User Flows
05 — Homepage
06 — Navigation
07 — Search
08 — Categories / PLP
09 — Product
10 — Cart
11 — Checkout
12 — Account
13 — Orders / Tracking
14 — Services
15 — Responsive / Mobile
16 — Components
17 — Prototype Notes
```

The first Figma phase should be **structural wireframes**, followed by high-fidelity application of the Amaal Design System V1.

The Figma work should not be used to invent backend data; product/category content must be based on verified public-safe data.

# 35. Figma Wireframe Priority

First prototype:

1. Homepage
2. Desktop navigation / mega menu
3. Mobile navigation
4. Search overlay/results
5. Category listing
6. Product detail
7. Cart
8. Checkout
9. Account dashboard
10. Order tracking
11. Warranty/service request

# 36. Phased Delivery

## Phase 1 — Brand + Discovery

- Design System
- Header
- Footer
- Homepage
- Categories
- Search
- Product listing
- Product detail
- Brands
- Deals

## Phase 2 — Commerce

- Cart
- Checkout
- Payment
- Order confirmation
- Customer account
- Orders
- Tracking

## Phase 3 — Self-Service

- Delivery
- Returns
- Warranty
- Repairs/service
- Support
- Enquiries

## Phase 4 — Optimization

- analytics refinement;
- search refinement;
- merchandising;
- personalization where justified;
- performance optimization;
- accessibility refinement;
- conversion optimization.

# 37. Open Decisions Requiring System Inspection

Do not invent answers for:

- actual top-level categories;
- actual taxonomy;
- actual brands;
- actual product attributes;
- actual variants;
- public availability model;
- cart model;
- guest checkout support;
- customer account model;
- delivery model;
- payment provider/methods;
- order state model;
- return workflow;
- warranty data/workflow;
- repairs/service workflow;
- CMS/content model;
- FAQ management;
- promotion management;
- media system;
- existing public pages/components;
- repository conventions.

The engineering handoff explicitly instructs the next phase to inspect the actual project, backend, database, Business Admin Console, public work and tooling before implementation. fileciteturn1file7L1679-L1750

# 38. Definition of Blueprint V1 Done

This blueprint is ready for the next phase when the team agrees on:

- public sitemap;
- navigation model;
- category/brand/search discovery model;
- homepage structure;
- PLP structure;
- product-page hierarchy;
- cart/checkout journey;
- account/self-service model;
- after-sales journeys;
- mobile strategy;
- content/service architecture;
- Figma wireframe priorities;
- backend/API verification plan.

# 39. Next Step

The next step is **not full implementation**.

It is a verified system inspection:

```text
BUSINESS REQUIREMENT
        ↓
EXISTING BACKEND CAPABILITY
        ↓
EXISTING API
        ↓
PUBLIC-SAFE?
        ↓
REUSE / EXTEND / CREATE
        ↓
FRONTEND EXPERIENCE
```

Then build the first Figma structural UX screens and review them before applying high-fidelity visual design.

# 40. Final North Star

> **Amaal should be the place customers trust to discover, understand, buy and get support for consumer electronics — with the sophistication of a premium retailer and the simplicity of an everyday shopping experience.**

**Amaal Public Website Information Architecture & UX Blueprint V1 — PROPOSED FOR APPROVAL**

## Research References

- Baymard Institute — Homepage & Category Navigation UX. citeturn0search0turn0search1
- Baymard Institute — Product Page UX 2026. citeturn0search2
- Baymard Institute — Mobile App UX Trends 2026. citeturn0search8
- Nielsen Norman Group — Ecommerce UX: Search, Filters and Routing Pages. citeturn0search4
- Google Search Central — current product/product-variant structured data guidance. citeturn0search10turn0search13
- Shopify — Mobile Commerce Trends 2026. citeturn0search5
