# Amaal Public Website System Audit & Implementation Blueprint V1

**Status:** Verified planning baseline  
**Date:** 29 August 2026  
**Brand:** Amaal  
**Purpose:** Customer-facing premium consumer electronics website

---

## 1. Executive Decision

Amaal should **not rebuild the existing business platform**.

The correct architecture is:

```text
Amaal Public Website
        ↓
Public Web Data / API Client
        ↓
Public-safe Backend APIs
        ↓
Existing Business Logic
        ↓
Existing Database
```

The supplied engineering handoff explicitly requires the public website to sit on top of the existing backend/database and prohibits destructive database changes, unnecessary backend replacement, unnecessary API rewrites, duplicate sources of truth and replacement of the existing Business Admin Console.

This becomes the architectural rule for the entire project.

---

# 2. What We Know

The project is moving publicly as **Amaal**, not automatically as “Amaal Telecoms”.

The existing repository may retain historical/internal Telecoms naming. Those internal names should not be blindly renamed.

The public brand is intentionally expanding beyond a narrow telecom identity into a multi-category consumer electronics retailer.

The engineering handoff states that the existing system already contains core backend infrastructure, an established database and an internal Business Admin Console. It lists business domains including products, categories, inventory, sales, customers, orders, purchasing, suppliers, finance, delivery, returns, warranty, repairs, users, permissions, reporting and administration, while explicitly requiring the implementation team to verify which of these are actually present rather than assuming them.

Source: Amaal Engineering Handoff, Product Identity / Current Engineering State.

---

# 3. Non-Negotiable Preservation Rules

Do not:

- reset the database;
- drop tables;
- recreate the database;
- delete records;
- replace the backend without justification;
- rewrite working APIs unnecessarily;
- destroy authentication;
- remove security work;
- replace the Business Admin Console;
- introduce a second source of truth;
- perform destructive migrations;
- blindly rename historical/internal entities.

If backend work is required, it should be:

- minimal;
- additive where possible;
- backward-compatible;
- documented;
- tested;
- non-destructive.

---

# 4. Public Website Boundary

The public website may expose approved customer-safe information such as:

- published products;
- public categories;
- approved pricing;
- public descriptions;
- public images;
- approved promotions;
- public content;
- FAQs;
- delivery information;
- return information;
- warranty information;
- public contact information.

It must not expose:

- supplier costs;
- margins;
- private stock quantities unless deliberately public;
- employee information;
- internal finance;
- internal notes;
- internal operations;
- technical configuration;
- secrets;
- admin permissions;
- private customer data;
- audit data.

---

# 5. Customer Product Model

The public catalogue must support the actual Amaal multi-category structure.

Target customer-facing categories include:

- Phones
- Tablets
- Home Appliances
- Kitchen Appliances
- Office Electronics
- TVs
- Refrigeration
- Sound & Speakers

However, the final hierarchy must be generated from the actual catalogue taxonomy in the backend.

Do not invent a taxonomy that the business system cannot support.

---

# 6. Public Commerce Model

The public experience should connect:

```text
HOME
↓
DISCOVER
↓
CATEGORY / SEARCH
↓
PRODUCT
↓
CART
↓
CHECKOUT
↓
PAYMENT
↓
ORDER CONFIRMATION
↓
ORDER TRACKING
↓
DELIVERY
↓
AFTER-SALES
```

The engineering handoff defines this as the intended coherent customer journey.

---

# 7. Public API Capability Matrix

| Capability | Requirement | Verification | Decision |
|---|---|---|---|
| Published products | Required | Existing public catalogue work identified | Reuse / verify |
| Categories | Required | Existing catalogue/business model | Reuse / verify |
| Brands | Required | Existing catalogue/business model | Reuse / verify |
| Search | Required | Must verify implementation | Verify / extend |
| Filters | Required | Must map to real attributes | Extend if needed |
| Sorting | Required | Must verify | Reuse / extend |
| Product detail | Required | Public catalogue capability exists | Reuse / extend |
| Variants | Required | Backend source of truth | Verify |
| Availability | Required | Must be public-safe | Verify |
| Promotions | Required | Existing promotions domain | Verify public exposure |
| Public content | Required | Web/content domain indicated | Reuse / verify |
| FAQs | Required | Public capability proposed | Verify |
| Cart | Required | Commerce requirement | Verify / extend |
| Checkout | Required | Commerce requirement | Verify / extend |
| Payment | Required | Existing architecture governs | Verify |
| Orders | Required | Existing order domain | Verify |
| Customer accounts | Required | Existing customer/auth foundation | Verify |
| Tracking | Required | Delivery/order domains | Verify |
| Returns | Required | Existing return domain | Verify |
| Warranty | Required | Existing warranty domain | Verify |
| Repairs/service | Required | Existing repair domain | Verify |
| Enquiries/leads | Required by business brief | Must verify | Extend if absent |

**Important:** “Verify” means we do not infer a finished public API merely because the business domain exists internally.

---

# 8. Product Discovery Requirements

The public site must support:

- category browsing;
- search;
- filtering;
- sorting;
- pagination or efficient loading;
- related products;
- featured products;
- promotions.

The handoff explicitly prohibits fake filters.

Every filter must correspond to real product data.

---

# 9. Product Page Contract

A product page should provide:

- product images;
- product name;
- brand;
- price;
- promotion;
- public availability;
- variants;
- specifications;
- description;
- delivery information;
- warranty information;
- related products;
- add-to-cart.

The exact data structure must be derived from the backend.

No duplicate product model should be created unless absolutely necessary.

---

# 10. Cart Contract

Customer actions:

- add item;
- update quantity;
- remove item;
- persist cart;
- calculate totals;
- apply approved promotions.

Backend remains authoritative for:

- price;
- promotion validation;
- availability;
- checkout validation.

Client-side totals are never authoritative.

---

# 11. Checkout Contract

Target flow:

```text
CUSTOMER INFORMATION
        ↓
DELIVERY
        ↓
PAYMENT
        ↓
REVIEW
        ↓
CONFIRM
```

Do not build a parallel order-processing system.

---

# 12. Payment Security Boundary

Correct model:

```text
Customer
↓
Public Website
↓
Backend
↓
Payment Provider
↓
Backend Verification
↓
Order State
↓
Customer Confirmation
```

The frontend must never contain:

- payment secrets;
- provider private credentials;
- webhook secrets.

The frontend must not independently decide that a payment succeeded.

---

# 13. Account Model

Customer accounts are separate from internal staff accounts.

Target capabilities:

- registration;
- login;
- profile;
- addresses;
- orders;
- order tracking;
- saved products;
- returns;
- warranty;
- support.

Existing authentication should be reused where appropriate.

Do not create an incompatible second authentication system.

---

# 14. After-Sales Model

## Returns

```text
ORDER
↓
ELIGIBLE PRODUCT
↓
RETURN REQUEST
↓
REVIEW
↓
STATUS
```

## Warranty

```text
PRODUCT
↓
WARRANTY INFORMATION
↓
CLAIM
↓
STATUS
```

## Repairs / Service

```text
DEVICE
↓
ISSUE
↓
SERVICE REQUEST
↓
ASSESSMENT
↓
STATUS
```

The backend/business system makes operational decisions.

The website provides the customer experience.

---

# 15. Content Architecture

Public information should eventually include:

- About;
- Contact;
- FAQ;
- Delivery;
- Returns;
- Warranty;
- Privacy;
- Terms;
- approved policies.

Where the existing content system supports it, content should be manageable without unnecessary code deployments.

---

# 16. Public Website Navigation

Recommended primary navigation:

```text
AMAAL

Shop
Categories
Brands
Deals
Services

Search
Account
Bag
```

### Desktop

Use a restrained premium mega menu.

### Mobile

Use a dedicated navigation drawer rather than compressing desktop navigation.

Primary mobile tasks:

- search;
- browse categories;
- discover products;
- open product;
- add to bag;
- checkout;
- account/order tracking.

---

# 17. Homepage Structure

The homepage remains the commercial front door:

```text
Header
↓
Hero
↓
Trust / Value
↓
Featured Categories
↓
Featured Products
↓
Promotions
↓
Why Amaal
↓
Service / Delivery
↓
Brand Story
↓
Final CTA
↓
Footer
```

Featured products must use real public-safe data.

Promotions must use approved active offers.

---

# 18. Premium UX Direction

The approved design direction is:

> **Lightweight Premium Modern Luxury**

The site should feel:

- light;
- premium;
- modern;
- confident;
- genuine;
- easy.

Avoid:

- excessive black/gold;
- heavy gradients;
- neon tech aesthetics;
- excessive cards;
- oversized shadows;
- unnecessary animation;
- luxury styling that makes shopping harder.

The premium feeling should come from:

- whitespace;
- typography;
- image quality;
- restrained colour;
- grid discipline;
- material/detail;
- confident hierarchy.

---

# 19. Responsive Baseline

Design intentionally for:

### Mobile

360px  
375px  
390px  
412px

### Tablet

768px  
820px

### Desktop

1024px  
1280px  
1440px  
1920px

Do not simply compress desktop layouts.

---

# 20. Accessibility Baseline

Required:

- semantic HTML;
- keyboard navigation;
- visible focus;
- accessible labels;
- descriptive alt text;
- meaningful heading hierarchy;
- adequate contrast;
- accessible forms;
- adequate touch targets;
- reduced-motion consideration;
- non-colour-only state communication.

---

# 21. Performance Baseline

Prioritize:

### Images

- optimized formats;
- responsive sizes;
- correct dimensions;
- lazy loading where appropriate.

### JavaScript

- minimal unnecessary dependencies;
- minimized client-side work;
- reasonable bundles.

### Data

- pagination;
- caching;
- efficient requests;
- avoid duplicate API calls.

### Perceived performance

- skeleton states;
- intentional loading;
- safe optimistic UI only.

---

# 22. SEO Baseline

Important pages should support:

- title;
- meta description;
- canonical URL;
- Open Graph metadata;
- semantic headings;
- structured data where appropriate;
- sitemap;
- robots configuration.

Product/category pages should be crawlable where appropriate.

Structured data must match visible, authoritative data.

---

# 23. Frontend Architecture

The engineering handoff proposes a customer-facing application structure around:

```text
app/
components/
features/
services/api/
hooks/
lib/
styles/
types/
```

Feature areas:

```text
products
categories
search
cart
checkout
orders
account
```

For the expanded Amaal brief, add customer-facing service areas:

```text
brands
promotions
returns
warranty
repairs
enquiries
content
```

This is a conceptual target, not a reason to restructure the existing repository blindly.

---

# 24. Reusable Component Foundation

Initial shared components:

```text
Header
MobileNavigation
Footer

Button
IconButton
Input
SearchInput
Select
Checkbox
Radio
Badge
Tag

Modal
Drawer
Toast

Skeleton
LoadingState
EmptyState
ErrorState

Breadcrumbs
Pagination

ProductCard
CategoryCard
PromotionCard
BrandCard
PriceDisplay
QuantityControl
ProductGallery

SectionHeading
ContentContainer
```

Only create abstractions when repetition justifies them.

---

# 25. Analytics

Recommended customer events:

```text
page_view
search_performed
category_viewed
product_viewed
filter_applied
variant_selected
add_to_cart
remove_from_cart
cart_viewed
checkout_started
checkout_step_completed
payment_started
order_completed
order_tracking_viewed
return_started
warranty_started
service_request_started
lead_submitted
```

Do not collect unnecessary sensitive information.

---

# 26. Competitive Research — Strategic Implication

Current Uganda-facing ecommerce/electronics competitors commonly communicate:

- broad electronics/appliance selection;
- known brands;
- online ordering;
- delivery;
- payment convenience;
- warranty;
- authenticity/value.

Therefore Amaal cannot differentiate simply by saying:

> “We sell electronics.”

The strategic opportunity is to combine:

```text
PREMIUM BRAND
+
GENUINE PRODUCTS
+
EXCEPTIONAL DISCOVERY
+
CLEAR PRODUCT INFORMATION
+
SEAMLESS PURCHASE
+
DELIVERY VISIBILITY
+
STRONG AFTER-SALES
```

This is a research-informed recommendation, not an existing Amaal backend requirement.

---

# 27. Figma Architecture

The Figma UX Architecture board has been started.

Working structure:

```text
01 — UX Architecture
02 — Information Architecture
03 — User Flows
04 — Homepage
05 — Navigation
06 — Search
07 — Categories / PLP
08 — Product
09 — Cart
10 — Checkout
11 — Account
12 — Orders / Tracking
13 — Services
14 — Mobile
15 — Components
16 — High Fidelity
17 — Prototype
```

Current Figma file:

https://www.figma.com/design/4LnvxI3mJYeJ63n8Q4ErZ6

The existing board is intentionally structural and wireframe-ready rather than prematurely high-fidelity.

---

# 28. Implementation Phases

The engineering handoff defines the following sequence:

### PW-0 — Discovery & Discussion

Inspect → report → discuss → agree.

### PW-1 — Public Website Foundation

Routing, design tokens, typography, global styles, layout, API integration, loading/error patterns and responsive foundation.

### PW-2 — Navigation & Shared Layout

Header, mobile navigation, search, account, cart, footer.

### PW-3 — Homepage

Hero, value proposition, categories, products, promotions, trust, services, brand content and CTA.

### PW-4 — Product Discovery

Shop, categories, search, filtering, sorting and pagination.

### PW-5 — Product Experience

Product detail, gallery, specifications, variants, pricing, related products and purchase actions.

### PW-6 — Deals & Campaigns

Deals, promotions and campaign sections.

### PW-7 — Cart

Cart state, item management, totals, promotions and validation.

### PW-8 — Checkout & Payment

Checkout, delivery, payment and confirmation.

### PW-9 — Customer Account

Authentication, profile, addresses, orders and tracking.

### PW-10 — After-Sales

Returns, warranty, repairs/service and support.

### PW-11 — Content

About, Contact, FAQ, Delivery and Policies.

### PW-12 — Quality

SEO, performance, accessibility and responsive review.

### PW-13 — Production Readiness

Security review, API boundary review, authorization testing, production build, regression testing and deployment readiness.

---

# 29. Definition of Done

A feature is not finished simply because it renders.

Appropriate features must have:

- real data integration;
- no unnecessary mock data;
- mobile support;
- tablet support;
- desktop support;
- loading state;
- error state;
- empty state where relevant;
- accessibility consideration;
- preserved security boundaries;
- API error handling;
- tests;
- type checking;
- linting;
- successful production build.

---

# 30. Current Priority

The immediate priority is **not full implementation**.

It is:

```text
VERIFY
↓
MAP
↓
DESIGN
↓
APPROVE
↓
IMPLEMENT
```

Specifically, the next engineering/design work should verify the exact:

1. public catalogue contract;
2. category taxonomy;
3. brand model;
4. product/variant model;
5. search/filter capabilities;
6. cart endpoints;
7. checkout endpoints;
8. payment integration;
9. customer authentication;
10. order/tracking APIs;
11. promotion APIs;
12. delivery APIs;
13. returns;
14. warranty;
15. repair/service;
16. enquiries/leads;
17. content/CMS capabilities.

---

# 31. Immediate Build Order

Once those capabilities are confirmed:

```text
1. Design tokens
2. Global layout
3. Header
4. Mobile navigation
5. Search
6. Homepage
7. Category / PLP
8. Product page
9. Cart
10. Checkout
11. Account
12. Order tracking
13. Deals
14. Warranty
15. Returns
16. Repairs
17. Enquiries
18. Content
19. SEO
20. Accessibility
21. Performance
22. Security
23. Production QA
```

---

# 32. Final Architecture Decision

### KEEP

Existing:

- backend;
- database;
- business logic;
- authentication;
- Business Admin Console;
- existing business domains;
- existing public-safe catalogue work;
- security architecture.

### EXTEND

Where verified gaps exist:

- public API contracts;
- search;
- filters;
- commerce endpoints;
- customer account journeys;
- delivery/tracking;
- after-sales;
- enquiries;
- public content.

### BUILD

The new:

> **Amaal Customer-Facing Public Website**

with the premium modern luxury experience defined in the Design System and UX Blueprint.

---

# 33. North Star

Amaal should become:

> **The premium, trusted and genuine place to discover, understand, buy and get support for consumer electronics.**

The interface should make that proposition obvious within seconds, while remaining simple enough for everyday customers to shop without friction.

**Amaal Public Website System Audit & Implementation Blueprint V1**
