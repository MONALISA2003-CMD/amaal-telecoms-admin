# Vercel Build Notes

## Critical TypeScript fix

The Business workspace card factory now explicitly returns `Card[]`-compatible objects with:

- `label: string`
- `value: string`

Both `page.tsx` and `lib/business.ts` normalize the label and value with `String(...)`. This prevents TypeScript from widening tuple values into `string | number` and removes the exact TS2322 failure seen at `app/(business)/[...slug]/page.tsx` lines 85 and 94.

## Next.js 16 proxy migration

The application uses `proxy.ts` and has no `middleware.ts`/`middleware.js` file.

## Database safety

No PostgreSQL client, database URL, SQL migration, seed, reset, schema modification, or direct database access exists in the Business Admin app. All business data remains sourced through the existing Amaal Engine API, preserving PostgreSQL as the source of truth.

## Deployment verification

The file `BUILD_SOURCE_FINGERPRINT.txt` identifies this audited source package. If Vercel still reports the old Card label error or reports `eslint@9.0.0`, the deployed Git commit does not contain this package's current `apps/business-admin/package.json` and source files.
