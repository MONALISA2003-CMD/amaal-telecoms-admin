# Vercel build and production-safety audit

## Build fixes completed

1. Corrected `@tanstack/react-query` from the unresolvable `5.90.0` pin to `5.102.4`.
2. Corrected the Business Workspace card typing by keeping labels as strings and formatting values before rendering. This fixes the Vercel TypeScript errors at `app/(business)/[...slug]/page.tsx`.
3. Migrated the Next.js 16 request file from `middleware.ts` to `proxy.ts` and removed stale middleware files.
4. Added a current ESLint flat configuration compatible with Next.js 16.
5. Updated ESLint from deprecated `9.0.0` to `9.39.5`.
6. Added explicit upstream error handling to the Vercel API proxy and login bridge so an unavailable Render service returns a controlled 502/503 response instead of crashing the Vercel function.
7. Removed the production fallback to `localhost:10000`. Local development may use that fallback, but production requires `AMAAL_ENGINE_URL`.
8. Changed business metric formatting so missing upstream data displays `—` rather than silently becoming `0`.
9. Quick actions are filtered by the permissions returned by the existing backend.

## Data-source rule

The Business Admin does not connect to PostgreSQL and does not contain SQL migrations, seeds, resets, or schema changes. Business data is read through the existing Render Amaal Engine API. PostgreSQL remains the authoritative source of truth behind that engine.

No database connection or database mutation was performed while preparing this package.

## Required production configuration

- Vercel Framework: Next.js
- Vercel Root Directory: `apps/business-admin`
- Node.js: 24.x
- `AMAAL_ENGINE_URL`: the public HTTPS URL of the existing Render Amaal Engine

Do not set `AMAAL_ENGINE_URL` to `localhost` in production.
