-- Global Search & Operational UX indexes. Safe on existing installations.
CREATE INDEX IF NOT EXISTS idx_products_search_name ON products USING gin (to_tsvector('simple', coalesce(name,'')));
CREATE INDEX IF NOT EXISTS idx_customers_search_name ON customers USING gin (to_tsvector('simple', coalesce(name,'')));
CREATE INDEX IF NOT EXISTS idx_suppliers_search_legal_name ON suppliers USING gin (to_tsvector('simple', coalesce(legal_name,'')));
CREATE INDEX IF NOT EXISTS idx_sales_search_sale_no ON sales(sale_no);
CREATE INDEX IF NOT EXISTS idx_orders_search_order_no ON orders(order_no);
CREATE INDEX IF NOT EXISTS idx_serialized_units_search_serial ON serialized_units(serial_number);
CREATE INDEX IF NOT EXISTS idx_serialized_units_search_imei1 ON serialized_units(imei1);
CREATE INDEX IF NOT EXISTS idx_serialized_units_search_imei2 ON serialized_units(imei2);
CREATE INDEX IF NOT EXISTS idx_documents_search_name ON documents USING gin (to_tsvector('simple', coalesce(name,'')));
