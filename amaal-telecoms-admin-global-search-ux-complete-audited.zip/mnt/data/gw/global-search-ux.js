export function registerGlobalSearchUX({app,auth,need,q}){
 const esc=(v)=>String(v??'').replace(/[%_]/g,'\\$&');
 const text=(v)=>String(v??'').trim().slice(0,120);
 app.get('/api/global-search',auth,need('search.view'),async(req,res,next)=>{
  try{
   const term=text(req.query.q); const limit=Math.min(Math.max(Number(req.query.limit)||30,1),100);
   if(term.length<2)return res.json({query:term,results:[],total:0});
   const p=`%${esc(term)}%`;
   const results=[];
   const add=async(type,sql,params)=>{for(const r of await q(sql,params))results.push({...r,type})};
   await add('Product',`SELECT p.id,p.name title,COALESCE(b.name,'') subtitle,COALESCE(p.status,'') status,'catalog' module FROM products p LEFT JOIN brands b ON b.id=p.brand_id WHERE p.name ILIKE $1 OR p.slug ILIKE $1 OR COALESCE(b.name,'') ILIKE $1 OR EXISTS(SELECT 1 FROM product_variants v WHERE v.product_id=p.id AND v.sku ILIKE $1) ORDER BY p.updated_at DESC LIMIT 15`,[p]);
   await add('Customer',`SELECT c.id,c.name title,concat_ws(' · ',c.customer_no,c.phone,c.email) subtitle,COALESCE(c.status,'') status,'customers' module FROM customers c WHERE c.name ILIKE $1 OR c.customer_no ILIKE $1 OR COALESCE(c.phone,'') ILIKE $1 OR COALESCE(c.email,'') ILIKE $1 ORDER BY c.updated_at DESC LIMIT 15`,[p]);
   await add('Supplier',`SELECT s.id,s.legal_name title,concat_ws(' · ',s.supplier_code,s.email,s.phone) subtitle,COALESCE(s.status,'') status,'procurement' module FROM suppliers s WHERE s.legal_name ILIKE $1 OR s.supplier_code ILIKE $1 OR COALESCE(s.email,'') ILIKE $1 OR COALESCE(s.phone,'') ILIKE $1 ORDER BY s.updated_at DESC LIMIT 15`,[p]);
   await add('Sale',`SELECT s.id,s.sale_no title,concat_ws(' · ',COALESCE(c.name,'Walk-in'),s.status) subtitle,COALESCE(s.status,'') status,'sales' module FROM sales s LEFT JOIN customers c ON c.id=s.customer_id WHERE s.sale_no ILIKE $1 OR COALESCE(c.name,'') ILIKE $1 ORDER BY s.created_at DESC LIMIT 15`,[p]);
   await add('Order',`SELECT o.id,o.order_no title,concat_ws(' · ',COALESCE(c.name,'Walk-in'),o.status) subtitle,COALESCE(o.status,'') status,'orders' module FROM orders o LEFT JOIN customers c ON c.id=o.customer_id WHERE o.order_no ILIKE $1 OR COALESCE(c.name,'') ILIKE $1 ORDER BY o.created_at DESC LIMIT 15`,[p]);
   await add('IMEI / Serial',`SELECT su.id,COALESCE(su.imei1,su.imei2,su.serial_number) title,concat_ws(' · ',v.sku,su.status) subtitle,COALESCE(su.status,'') status,'inventory' module FROM serialized_units su JOIN product_variants v ON v.id=su.variant_id WHERE COALESCE(su.imei1,'') ILIKE $1 OR COALESCE(su.imei2,'') ILIKE $1 OR COALESCE(su.serial_number,'') ILIKE $1 LIMIT 15`,[p]);
   await add('Document',`SELECT d.id,d.name title,concat_ws(' · ',d.entity_type,d.status) subtitle,COALESCE(d.status,'') status,'documents' module FROM documents d WHERE d.name ILIKE $1 OR COALESCE(d.description,'') ILIKE $1 ORDER BY d.updated_at DESC LIMIT 15`,[p]);
   await add('Requisition',`SELECT r.id,r.requisition_no title,concat_ws(' · ',r.priority,r.status) subtitle,r.status status,'procurement' module FROM purchase_requisitions r WHERE r.requisition_no ILIKE $1 OR r.justification ILIKE $1 ORDER BY r.created_at DESC LIMIT 10`,[p]);
   await add('Supplier Invoice',`SELECT i.id,i.invoice_no title,concat_ws(' · ',s.legal_name,i.status) subtitle,i.status status,'procurement' module FROM supplier_invoices i JOIN suppliers s ON s.id=i.supplier_id WHERE i.invoice_no ILIKE $1 OR s.legal_name ILIKE $1 ORDER BY i.created_at DESC LIMIT 10`,[p]);
   await add('Delivery',`SELECT d.id,d.shipment_no title,concat_ws(' · ',d.tracking_number,d.status) subtitle,d.status status,'delivery' module FROM delivery_shipments d WHERE d.shipment_no ILIKE $1 OR d.tracking_number ILIKE $1 OR d.recipient_name ILIKE $1 OR d.recipient_phone ILIKE $1 ORDER BY d.created_at DESC LIMIT 10`,[p]);
   await add('Warranty Claim',`SELECT w.id,w.claim_no title,concat_ws(' · ',c.name,w.status) subtitle,w.status status,'warranty' module FROM warranty_claims w LEFT JOIN customers c ON c.id=w.customer_id WHERE w.claim_no ILIKE $1 OR w.issue ILIKE $1 OR COALESCE(c.name,'') ILIKE $1 ORDER BY w.created_at DESC LIMIT 10`,[p]);
   await add('Return',`SELECT r.id,r.return_no title,concat_ws(' · ',r.reason,r.status) subtitle,r.status status,'returns' module FROM return_requests r LEFT JOIN customers c ON c.id=r.customer_id WHERE r.return_no ILIKE $1 OR r.reason ILIKE $1 OR COALESCE(c.name,'') ILIKE $1 ORDER BY r.created_at DESC LIMIT 10`,[p]);
   await add('Credit Account',`SELECT a.id,a.account_no title,concat_ws(' · ',c.name,a.status) subtitle,a.status status,'credit' module FROM credit_accounts a JOIN customers c ON c.id=a.customer_id WHERE a.account_no ILIKE $1 OR c.name ILIKE $1 ORDER BY a.opened_at DESC LIMIT 10`,[p]);
   await add('Finance Journal',`SELECT j.id,j.journal_no title,concat_ws(' · ',j.source_type,j.status) subtitle,j.status status,'finance' module FROM finance_journals j WHERE j.journal_no ILIKE $1 OR j.description ILIKE $1 OR j.source_ref ILIKE $1 ORDER BY j.created_at DESC LIMIT 10`,[p]);
   
   results.sort((a,b)=>String(b.status||'').localeCompare(String(a.status||'')));
   res.json({query:term,results:results.slice(0,limit),total:results.length});
  }catch(e){next(e)}
 });
 app.get('/api/global-search/health',auth,need('search.view'),async(_req,res,next)=>{try{const [products,customers,suppliers,sales,orders,docs]=await Promise.all(['products','customers','suppliers','sales','orders','documents'].map(t=>q(`SELECT count(*)::int c FROM ${t}`)));res.json({ok:true,indexedSources:{products:products[0].c,customers:customers[0].c,suppliers:suppliers[0].c,sales:sales[0].c,orders:orders[0].c,documents:docs[0].c}})}catch(e){next(e)}});
}
