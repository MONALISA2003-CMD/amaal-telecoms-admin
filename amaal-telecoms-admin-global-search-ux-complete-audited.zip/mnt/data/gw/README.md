# Amaal Telecoms Admin System

Cumulative enterprise telecom retail administration platform.

## Modules
Catalog · Inventory · Suppliers & Procurement · Customers & CRM · Sales & POS · Orders & E-commerce · Pricing & Promotions · Delivery & Logistics · Warranty & Repairs · Returns & Refunds · Document Management · Credit & Installments · Finance & Accounting · Reporting & Business Intelligence · AI Business Intelligence · Web & Hosting · Integration Hub · Workflow & Automation · Global Search, UX & Operational Polish

## Deployment
- Node.js 20.x
- PostgreSQL
- Start command: `node render-preflight.js && node server.js`
- Never package `node_modules`.
- Never commit secrets.
- Do not reset PostgreSQL.
- Do not introduce YAML as an application workaround.

## Security roadmap
MFA is intentionally deferred to the final security phase and must remain untouched until the Full System Audit is complete.

See `CONTINUATION.md` for the current state and next-module instructions.
