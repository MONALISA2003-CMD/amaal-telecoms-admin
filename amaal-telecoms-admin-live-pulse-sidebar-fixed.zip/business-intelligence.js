export function registerBusinessIntelligence({app,auth,need,q,pool,audit}){
 const n=v=>Number(v||0);
 const text=v=>String(v??'').trim();
 const iso=v=>{const s=text(v);if(!/^\d{4}-\d{2}-\d{2}$/.test(s))return null;const d=new Date(`${s}T00:00:00Z`);return Number.isNaN(d.getTime())?null:s};
 function range(req){
   const today=new Date().toISOString().slice(0,10);
   let end=iso(req.query.end)||today;
   let start=iso(req.query.start)||new Date(Date.now()-29*86400000).toISOString().slice(0,10);
   if(start>end)[start,end]=[end,start];
   return {start,end};
 }
 function csvEsc(v){const x=String(v??'');return /[",\n]/.test(x)?`"${x.replaceAll('"','""')}"`:x}
 function locationFilter(req){const id=text(req.query.locationId);return id&&/^[0-9a-f-]{36}$/i.test(id)?id:null}
 async function safeQuery(sql,params=[],label='business data'){
  try{return {rows:await q(sql,params),ok:true};}
  catch(error){console.error('Business intelligence query failed',{label,message:error?.message||String(error)});return {rows:[],ok:false};}
 }
 async function locations(){return q("SELECT id,name FROM inventory_locations ORDER BY name")}
 
 app.get('/api/bi/summary',auth,need('bi.view'),async(req,res)=>{
  const {start,end}=range(req),loc=locationFilter(req), params=loc?[start,end,loc]:[start,end], locSql=loc?' AND s.location_id=$3':'';
  const queries=[
   ['sales',`SELECT COALESCE(sum(s.grand_total),0)::numeric revenue,count(*)::int transactions,COALESCE(sum(s.discount_amount),0)::numeric discounts,COALESCE(sum(s.tax_amount),0)::numeric tax FROM sales s WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 ${locSql}`,params],
   ['margin',`SELECT COALESCE(sum((sl.unit_price*sl.quantity)-sl.discount_amount),0)::numeric revenue,COALESCE(sum(sl.cost_price*sl.quantity),0)::numeric cost,COALESCE(sum(((sl.unit_price*sl.quantity)-sl.discount_amount)-(sl.cost_price*sl.quantity)),0)::numeric gross_margin FROM sales s JOIN sale_lines sl ON sl.sale_id=s.id WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 ${loc?' AND s.location_id=$3':''}`,params],
   ['orders',`SELECT count(*)::int total,count(*) FILTER(WHERE status='Delivered')::int delivered,count(*) FILTER(WHERE status='Cancelled')::int cancelled,count(*) FILTER(WHERE status IN ('Pending Payment','Paid','Processing','Packed','Ready for Dispatch','Dispatched'))::int open FROM orders WHERE created_at::date BETWEEN $1 AND $2 ${loc?' AND location_id=$3':''}`,params],
   ['returns',"SELECT count(*)::int total,COALESCE(sum(refund_amount),0)::numeric refunded,count(*) FILTER(WHERE status IN ('Refunded','Restocked'))::int completed FROM return_requests WHERE created_at::date BETWEEN $1 AND $2",[start,end]],
   ['delivery',"SELECT count(*)::int shipments,COALESCE(sum(unit_count),0)::numeric units,COALESCE(sum(total_delivery_cost),0)::numeric cost,count(*) FILTER(WHERE status='Delivered')::int delivered FROM delivery_shipments WHERE created_at::date BETWEEN $1 AND $2",[start,end]],
   ['warranty',"SELECT count(*)::int claims,count(*) FILTER(WHERE status IN ('Resolved','Cancelled'))::int closed,count(*) FILTER(WHERE status NOT IN ('Resolved','Cancelled'))::int open,COALESCE(avg(EXTRACT(EPOCH FROM (COALESCE(resolved_at,now())-created_at))/86400),0)::numeric avg_days FROM warranty_claims WHERE created_at::date BETWEEN $1 AND $2",[start,end]],
   ['inventory',"SELECT COALESCE(sum(on_hand*COALESCE(v.cost_price,0)),0)::numeric stock_value,COALESCE(sum(on_hand),0)::numeric units,COUNT(DISTINCT b.variant_id)::int variants FROM inventory_balances b JOIN product_variants v ON v.id=b.variant_id",[]],
   ['credit',"SELECT COALESCE(sum(outstanding_principal),0)::numeric outstanding,count(*)::int accounts,count(*) FILTER(WHERE status='Defaulted')::int defaulted FROM credit_accounts WHERE status IN ('Active','Defaulted','Restructured')",[]],
   ['customers',"SELECT count(*)::int total,count(*) FILTER(WHERE created_at::date BETWEEN $1 AND $2)::int acquired FROM customers",[start,end]],
   ['procurement',"SELECT count(DISTINCT p.id)::int orders,COALESCE(sum((l.quantity*l.unit_price)-l.discount_amount),0)::numeric merchandise_value,COALESCE(sum(l.received_qty),0)::numeric received_units FROM purchase_orders p JOIN purchase_order_lines l ON l.purchase_order_id=p.id WHERE p.status<>'Cancelled' AND p.created_at::date BETWEEN $1 AND $2",[start,end]],
   ['finance',"SELECT COALESCE(sum(CASE WHEN a.account_type='Revenue' THEN l.credit-l.debit WHEN a.account_type='Expense' THEN l.debit-l.credit ELSE 0 END),0)::numeric net_activity FROM finance_journal_lines l JOIN finance_accounts a ON a.id=l.account_id JOIN finance_journals j ON j.id=l.journal_id WHERE j.status='Posted' AND j.journal_date BETWEEN $1 AND $2",[start,end]],
   ['payments',"SELECT method,COALESCE(sum(amount),0)::numeric amount,count(*)::int transactions FROM sale_payments sp JOIN sales s ON s.id=sp.sale_id WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 GROUP BY method ORDER BY amount DESC",[start,end]],
   ['receivables',"SELECT COALESCE(sum(debit-credit),0)::numeric balance FROM finance_journal_lines l JOIN finance_accounts a ON a.id=l.account_id WHERE a.account_type='Asset' AND a.name ILIKE '%receivable%'",[]],
   ['payables',"SELECT COALESCE(sum(credit-debit),0)::numeric balance FROM finance_journal_lines l JOIN finance_accounts a ON a.id=l.account_id WHERE a.account_type='Liability' AND a.name ILIKE '%payable%'",[]],
   ['tax',"SELECT COALESCE(sum(tax_amount),0)::numeric tax FROM sales WHERE status='Completed' AND created_at::date BETWEEN $1 AND $2",[start,end]]
  ];
  const results=await Promise.all(queries.map(([label,sql,args])=>safeQuery(sql,args,label)));
  const rows=Object.fromEntries(results.map(([result],i)=>[queries[i][0],result.rows]));
  const first=k=>Array.isArray(rows[k])?rows[k][0]||{}:{};
  const sales=first('sales'),margin=first('margin'),orders=first('orders'),returns=first('returns'),delivery=first('delivery'),warranty=first('warranty'),inventory=first('inventory'),credit=first('credit'),customers=first('customers'),procurement=first('procurement'),finance=first('finance'),receivables=first('receivables'),payables=first('payables'),tax=first('tax'),payments=rows.payments||[];
  const failed=queries.filter((_,i)=>!results[i][0].ok).map(x=>x[0]);
  const revenue=n(sales.revenue),gm=n(margin.gross_margin),refund=n(returns.refunded);
  res.json({range:{start,end},locationId:loc,sales,margin,orders,returns,delivery,warranty,inventory,credit,customers,procurement,finance,payments,paymentsByMethod:payments,receivables,payables,tax,netSales:Math.max(revenue-refund,0),grossMarginPct:revenue?gm/revenue*100:0,netMarginAfterRefundPct:revenue?Math.max(gm-refund,0)/revenue*100:0,deliveryCostPerUnit:n(delivery.units)?n(delivery.cost)/n(delivery.units):0,dataHealth:{complete:failed.length===0,partial:failed.length>0,failedSections:failed}});
 });

 app.get('/api/bi/locations',auth,need('bi.view'),async(req,res)=>res.json(await locations()));
 app.get('/api/bi/live-pulse',auth,need('dashboard.view'),async(req,res)=>{
  try {
    const {start,end}=range(req),loc=locationFilter(req), params=loc?[start,end,loc]:[start,end], locSql=loc?' AND s.location_id=$3':'';
    const queries=[
      ['sales',`SELECT COALESCE(sum(s.grand_total),0)::numeric revenue,count(*)::int transactions FROM sales s WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 ${locSql}`,params],
      ['orders',`SELECT count(*)::int total,count(*) FILTER(WHERE status IN ('Pending Payment','Paid','Processing','Packed','Ready for Dispatch','Dispatched'))::int open FROM orders WHERE created_at::date BETWEEN $1 AND $2 ${loc?' AND location_id=$3':''}`,params],
      ['inventory',`SELECT COALESCE(sum(b.on_hand),0)::numeric units,COUNT(DISTINCT b.variant_id)::int variants FROM inventory_balances b`,[]],
      ['customers',`SELECT count(*)::int total,count(*) FILTER(WHERE created_at::date BETWEEN $1 AND $2)::int acquired FROM customers`,[start,end]],
      ['margin',`SELECT COALESCE(sum(((sl.unit_price*sl.quantity)-sl.discount_amount)-(sl.cost_price*sl.quantity)),0)::numeric gross_margin FROM sales s JOIN sale_lines sl ON sl.sale_id=s.id WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 ${loc?' AND s.location_id=$3':''}`,params]
    ];
    const results=await Promise.all(queries.map(([label,sql,args])=>safeQuery(sql,args,`live pulse ${label}`)));
    const first=(index)=>results[index][0].rows[0]||{};
    const failed=queries.filter((_,i)=>!results[i][0].ok).map(x=>x[0]);
    const sales=first(0),orders=first(1),inventory=first(2),customers=first(3),margin=first(4);
    const revenue=n(sales.revenue),grossMargin=n(margin.gross_margin);
    let trend=[];
    const trendResult=await safeQuery(`SELECT s.created_at::date day,COALESCE(sum(s.grand_total),0)::numeric revenue FROM sales s WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 ${loc?'AND s.location_id=$3':''} GROUP BY 1 ORDER BY 1`,params,'live pulse trend');
    if(trendResult.ok) trend=trendResult.rows;
    else failed.push('trend');
    res.json({
      range:{start,end},
      sales,orders,inventory,customers,margin,
      grossMarginPct:revenue?grossMargin/revenue*100:0,
      trend,
      dataHealth:{complete:failed.length===0,partial:failed.length>0,failedSections:[...new Set(failed)]}
    });
  } catch (error) {
    console.error('Live business pulse failed unexpectedly', { message: error?.message || String(error) });
    res.json({
      range: range(req),
      sales:{revenue:0,transactions:0},
      orders:{total:0,open:0},
      inventory:{units:0,variants:0},
      customers:{total:0,acquired:0},
      margin:{gross_margin:0},
      grossMarginPct:0,
      trend:[],
      dataHealth:{complete:false,partial:true,failedSections:['live pulse']}
    });
  }
 });
 app.get('/api/bi/sales-trend',auth,need('bi.view'),async(req,res)=>{const {start,end}=range(req),loc=locationFilter(req);const result=await safeQuery(`SELECT s.created_at::date day,count(*)::int transactions,COALESCE(sum(s.grand_total),0)::numeric revenue,COALESCE(sum(s.discount_amount),0)::numeric discounts,COALESCE(sum(s.tax_amount),0)::numeric tax FROM sales s WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 ${loc?'AND s.location_id=$3':''} GROUP BY 1 ORDER BY 1`,loc?[start,end,loc]:[start,end],'sales trend');res.json(result.rows)});
 app.get('/api/bi/payment-methods',auth,need('bi.view'),async(req,res)=>{const {start,end}=range(req);res.json(await q("SELECT method,COALESCE(sum(amount),0)::numeric amount,count(*)::int transactions FROM sale_payments sp JOIN sales s ON s.id=sp.sale_id WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 GROUP BY method ORDER BY amount DESC",[start,end]))});
 app.get('/api/bi/cashiers',auth,need('bi.view'),async(req,res)=>{const {start,end}=range(req);res.json(await q("SELECT u.id,u.name,count(s.id)::int transactions,COALESCE(sum(s.grand_total),0)::numeric revenue,COALESCE(sum(s.discount_amount),0)::numeric discounts FROM sales s JOIN users u ON u.id=s.cashier_id WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 GROUP BY u.id,u.name ORDER BY revenue DESC",[start,end]))});
 app.get('/api/bi/products',auth,need('bi.view'),async(req,res)=>{const {start,end}=range(req);res.json(await q("SELECT v.id,v.sku,v.variant_name,p.name product_name,b.name brand_name,c.name category_name,COALESCE(sum(sl.quantity),0)::numeric units,COALESCE(sum(sl.line_total),0)::numeric revenue,COALESCE(sum(sl.cost_price*sl.quantity),0)::numeric cost,COALESCE(sum(sl.line_total-(sl.cost_price*sl.quantity)),0)::numeric gross_margin FROM sale_lines sl JOIN sales s ON s.id=sl.sale_id JOIN product_variants v ON v.id=sl.variant_id JOIN products p ON p.id=v.product_id LEFT JOIN brands b ON b.id=p.brand_id LEFT JOIN product_categories c ON c.id=p.category_id WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 GROUP BY v.id,v.sku,v.variant_name,p.name,b.name,c.name ORDER BY revenue DESC LIMIT 500",[start,end]))});
 app.get('/api/bi/inventory-ageing',auth,need('bi.view'),async(req,res)=>res.json(await q(`SELECT v.id,v.sku,p.name product_name,COALESCE(sum(b.on_hand),0)::numeric units,MAX(m.last_received) last_received,CASE WHEN MAX(m.last_received) IS NULL THEN NULL ELSE EXTRACT(DAY FROM now()-MAX(m.last_received))::int END age_days FROM inventory_balances b JOIN product_variants v ON v.id=b.variant_id JOIN products p ON p.id=v.product_id LEFT JOIN (SELECT variant_id,max(created_at) last_received FROM inventory_movements WHERE movement_type='RECEIPT' GROUP BY variant_id) m ON m.variant_id=v.id GROUP BY v.id,v.sku,p.name HAVING sum(b.on_hand)>0 ORDER BY age_days DESC NULLS LAST LIMIT 500`)));
 app.get('/api/bi/inventory-turnover',auth,need('bi.view'),async(req,res)=>{const {start,end}=range(req);res.json(await q("SELECT COALESCE(sum(sl.cost_price*sl.quantity),0)::numeric cogs,COALESCE((SELECT sum(on_hand*COALESCE(v.cost_price,0)) FROM inventory_balances b JOIN product_variants v ON v.id=b.variant_id),0)::numeric closing_stock,EXTRACT(DAY FROM ($2::date-$1::date)+1)::numeric days FROM sale_lines sl JOIN sales s ON s.id=sl.sale_id WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2",[start,end]))});
 app.get('/api/bi/delivery',auth,need('bi.view'),async(req,res)=>{const {start,end}=range(req);res.json(await q("SELECT COALESCE(p.name,'Unassigned') partner,count(*)::int shipments,COALESCE(sum(s.unit_count),0)::numeric units,COALESCE(sum(s.total_delivery_cost),0)::numeric total_cost,CASE WHEN sum(s.unit_count)>0 THEN (sum(s.total_delivery_cost)/sum(s.unit_count))::numeric ELSE 0 END unit_cost,count(*) FILTER(WHERE s.status='Delivered')::int delivered FROM delivery_shipments s LEFT JOIN delivery_partners p ON p.id=s.partner_id WHERE s.created_at::date BETWEEN $1 AND $2 GROUP BY p.name ORDER BY total_cost DESC",[start,end]))});
 app.get('/api/bi/warranty',auth,need('bi.view'),async(req,res)=>res.json(await q("SELECT COALESCE(p.name,'Internal') repair_partner,count(*)::int jobs,count(*) FILTER(WHERE j.status NOT IN ('Completed','Cancelled'))::int active_jobs,count(*) FILTER(WHERE j.status='Completed')::int completed_jobs,COALESCE(sum(j.partner_cost),0)::numeric partner_cost,COALESCE(avg(EXTRACT(EPOCH FROM (COALESCE(j.completed_at,now())-j.created_at))/86400),0)::numeric avg_days FROM repair_jobs j LEFT JOIN repair_partners p ON p.id=j.partner_id GROUP BY p.name ORDER BY active_jobs DESC,partner_cost DESC")));
 app.get('/api/bi/customers',auth,need('bi.view'),async(req,res)=>{const {start,end}=range(req);res.json(await q("SELECT c.id,c.customer_no,c.name,c.phone,c.customer_type,count(DISTINCT s.id)::int transactions,COALESCE(sum(sl.line_total),0)::numeric revenue,COALESCE(sum(sl.quantity),0)::numeric units FROM customers c LEFT JOIN sales s ON s.customer_id=c.id AND s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 LEFT JOIN sale_lines sl ON sl.sale_id=s.id GROUP BY c.id,c.customer_no,c.name,c.phone,c.customer_type HAVING count(DISTINCT s.id)>0 ORDER BY revenue DESC LIMIT 300",[start,end]))});
 app.get('/api/bi/categories',auth,need('bi.view'),async(req,res)=>{const {start,end}=range(req);res.json(await q("SELECT COALESCE(c.name,'Uncategorized') category,COALESCE(sum(sl.quantity),0)::numeric units,COALESCE(sum(sl.line_total),0)::numeric revenue,COALESCE(sum(sl.cost_price*sl.quantity),0)::numeric cost,COALESCE(sum(sl.line_total-(sl.cost_price*sl.quantity)),0)::numeric gross_margin FROM sale_lines sl JOIN sales s ON s.id=sl.sale_id JOIN product_variants v ON v.id=sl.variant_id JOIN products p ON p.id=v.product_id LEFT JOIN product_categories c ON c.id=p.category_id WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 GROUP BY c.name ORDER BY revenue DESC",[start,end]))});
 app.get('/api/bi/procurement',auth,need('bi.view'),async(req,res)=>{const {start,end}=range(req);res.json(await q("SELECT COALESCE(s.name,'Unknown supplier') supplier,count(DISTINCT p.id)::int purchase_orders,COALESCE(sum(l.quantity*l.unit_price-l.discount_amount),0)::numeric merchandise_value,COALESCE(sum(l.received_qty),0)::numeric received_units,CASE WHEN sum(l.quantity)>0 THEN sum(l.received_qty)/sum(l.quantity)*100 ELSE 0 END received_pct FROM purchase_orders p JOIN purchase_order_lines l ON l.purchase_order_id=p.id LEFT JOIN suppliers s ON s.id=p.supplier_id WHERE p.status<>'Cancelled' AND p.created_at::date BETWEEN $1 AND $2 GROUP BY s.name ORDER BY merchandise_value DESC",[start,end]))});
 app.get('/api/bi/returns',auth,need('bi.view'),async(req,res)=>{const {start,end}=range(req);res.json(await q("SELECT status,count(*)::int count,COALESCE(sum(refund_amount),0)::numeric refund_amount FROM return_requests WHERE created_at::date BETWEEN $1 AND $2 GROUP BY status ORDER BY count DESC",[start,end]))});
 app.get('/api/bi/credit-aging',auth,need('bi.view'),async(req,res)=>res.json(await q(`SELECT bucket,installments,outstanding FROM (SELECT CASE WHEN i.due_date>=CURRENT_DATE THEN 'Current' WHEN i.due_date>=CURRENT_DATE-30 THEN '1–30 days' WHEN i.due_date>=CURRENT_DATE-60 THEN '31–60 days' WHEN i.due_date>=CURRENT_DATE-90 THEN '61–90 days' ELSE '90+ days' END bucket,COUNT(*)::int installments,COALESCE(sum(GREATEST(i.principal_due+i.fee_due+i.penalty_due-i.paid_amount,0)),0)::numeric outstanding FROM credit_installments i JOIN credit_accounts a ON a.id=i.credit_account_id WHERE a.status IN ('Active','Defaulted','Restructured') AND i.status<>'Paid' GROUP BY 1) x ORDER BY CASE WHEN bucket='Current' THEN 1 WHEN bucket='1–30 days' THEN 2 WHEN bucket='31–60 days' THEN 3 WHEN bucket='61–90 days' THEN 4 ELSE 5 END`)));
 app.get('/api/bi/finance',auth,need('bi.view'),async(req,res)=>{const {start,end}=range(req);res.json(await q("SELECT a.code,a.name,a.account_type,COALESCE(sum(l.debit),0)::numeric debit,COALESCE(sum(l.credit),0)::numeric credit,COALESCE(sum(l.debit-l.credit),0)::numeric balance FROM finance_accounts a LEFT JOIN finance_journal_lines l ON l.account_id=a.id LEFT JOIN finance_journals j ON j.id=l.journal_id AND j.status='Posted' AND j.journal_date BETWEEN $1 AND $2 GROUP BY a.id ORDER BY a.code",[start,end]))});
 app.get('/api/bi/tax',auth,need('bi.view'),async(req,res)=>{const {start,end}=range(req);res.json(await q("SELECT COALESCE(sum(tax_amount),0)::numeric sales_tax,COALESCE(sum(grand_total-tax_amount),0)::numeric net_before_tax,count(*)::int transactions FROM sales WHERE status='Completed' AND created_at::date BETWEEN $1 AND $2",[start,end]))});

 app.get('/api/bi/snapshots',auth,need('bi.view'),async(req,res)=>{const iso=v=>/^\d{4}-\d{2}-\d{2}$/.test(String(v||''))?String(v):null;let start=iso(req.query.start),end=iso(req.query.end);const args=[];let where='';if(start&&end){if(start>end)[start,end]=[end,start];args.push(start,end);where='WHERE s.period_end >= $1 AND s.period_start <= $2';}res.json(await q(`SELECT s.id,s.report_key,s.period_start,s.period_end,s.generated_by,s.created_at,u.name generated_by_name FROM bi_report_snapshots s LEFT JOIN users u ON u.id=s.generated_by ${where} ORDER BY s.created_at DESC LIMIT 100`,args));});
 app.get('/api/bi/snapshots/:id',auth,need('bi.view'),async(req,res)=>{const r=(await q('SELECT * FROM bi_report_snapshots WHERE id=$1',[req.params.id]))[0];if(!r)return res.status(404).json({error:'Report snapshot not found'});res.json(r)});
 app.post('/api/bi/snapshots',auth,need('bi.manage'),async(req,res)=>{const {start,end}=range(req);const reportKey=text(req.body?.reportKey||'executive').slice(0,80)||'executive';const payload={generatedAt:new Date().toISOString(),range:{start,end},summary:(await q("SELECT COALESCE(sum(grand_total),0)::numeric revenue,count(*)::int transactions FROM sales WHERE status='Completed' AND created_at::date BETWEEN $1 AND $2",[start,end]))[0]};const r=(await q('INSERT INTO bi_report_snapshots(report_key,period_start,period_end,payload,generated_by) VALUES($1,$2,$3,$4,$5) RETURNING *',[reportKey,start,end,JSON.stringify(payload),req.user.id]))[0];await audit(req.user,'BI_SNAPSHOT_CREATED','BIReport',r.id,`Saved ${reportKey} report`,null,r,req.req);res.status(201).json(r)});
 app.delete('/api/bi/snapshots/:id',auth,need('bi.manage'),async(req,res)=>{const r=(await q('SELECT * FROM bi_report_snapshots WHERE id=$1',[req.params.id]))[0];if(!r)return res.status(404).json({error:'Report snapshot not found'});return res.status(409).json({error:'BI report snapshots are retained and cannot be permanently deleted.'})});
 app.get('/api/bi/export',auth,need('bi.export'),async(req,res)=>{const {start,end}=range(req);const type=text(req.query.type||'sales');let headers,rows;
  if(type==='products'){headers=['product','sku','units','revenue','cost','gross_margin'];rows=await q("SELECT p.name product,v.sku,COALESCE(sum(sl.quantity),0)::numeric units,COALESCE(sum(sl.line_total),0)::numeric revenue,COALESCE(sum(sl.cost_price*sl.quantity),0)::numeric cost,COALESCE(sum(sl.line_total-sl.cost_price*sl.quantity),0)::numeric gross_margin FROM sale_lines sl JOIN sales s ON s.id=sl.sale_id JOIN product_variants v ON v.id=sl.variant_id JOIN products p ON p.id=v.product_id WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 GROUP BY p.name,v.sku ORDER BY revenue DESC",[start,end])}
  else if(type==='delivery'){headers=['partner','shipments','units','total_cost','unit_cost','delivered'];rows=await q("SELECT COALESCE(p.name,'Unassigned') partner,count(*) shipments,COALESCE(sum(s.unit_count),0) units,COALESCE(sum(s.total_delivery_cost),0) total_cost,CASE WHEN sum(s.unit_count)>0 THEN sum(s.total_delivery_cost)/sum(s.unit_count) ELSE 0 END unit_cost,count(*) FILTER(WHERE s.status='Delivered') delivered FROM delivery_shipments s LEFT JOIN delivery_partners p ON p.id=s.partner_id WHERE s.created_at::date BETWEEN $1 AND $2 GROUP BY p.name ORDER BY total_cost DESC",[start,end])}
  else if(type==='cashiers'){headers=['cashier','transactions','revenue','discounts'];rows=await q("SELECT u.name cashier,count(s.id) transactions,COALESCE(sum(s.grand_total),0) revenue,COALESCE(sum(s.discount_amount),0) discounts FROM sales s JOIN users u ON u.id=s.cashier_id WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 GROUP BY u.name ORDER BY revenue DESC",[start,end])}
  else if(type==='payment-methods'){headers=['method','transactions','amount'];rows=await q("SELECT sp.method,count(*) transactions,COALESCE(sum(sp.amount),0) amount FROM sale_payments sp JOIN sales s ON s.id=sp.sale_id WHERE s.status='Completed' AND s.created_at::date BETWEEN $1 AND $2 GROUP BY sp.method ORDER BY amount DESC",[start,end])}
  else {headers=['date','transactions','revenue','discounts','tax'];rows=await q("SELECT created_at::date day,count(*)::int transactions,COALESCE(sum(grand_total),0)::numeric revenue,COALESCE(sum(discount_amount),0)::numeric discounts,COALESCE(sum(tax_amount),0)::numeric tax FROM sales WHERE status='Completed' AND created_at::date BETWEEN $1 AND $2 GROUP BY 1 ORDER BY 1",[start,end])}
  const csv=[headers.join(','),...rows.map(r=>headers.map(h=>csvEsc(r[h])).join(','))].join('\n');res.setHeader('Content-Type','text/csv; charset=utf-8');res.setHeader('Content-Disposition',`attachment; filename="amaal-bi-${type}-${start}-to-${end}.csv"`);res.send(csv);
 });
}
