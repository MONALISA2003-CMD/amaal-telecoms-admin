-- Warranty & Repairs
CREATE TABLE IF NOT EXISTS warranty_policies(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, brand_id uuid REFERENCES brands(id) ON DELETE SET NULL, category_id uuid REFERENCES product_categories(id) ON DELETE SET NULL, duration_days int NOT NULL CHECK(duration_days>0), coverage text NOT NULL DEFAULT '', exclusions text NOT NULL DEFAULT '', status text NOT NULL DEFAULT 'Active' CHECK(status IN ('Active','Inactive')), created_by uuid REFERENCES users(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS warranty_claims(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), claim_no text UNIQUE NOT NULL, customer_id uuid REFERENCES customers(id) ON DELETE SET NULL, order_id uuid REFERENCES orders(id) ON DELETE SET NULL, sale_id uuid REFERENCES sales(id) ON DELETE SET NULL, serialized_unit_id uuid REFERENCES serialized_units(id) ON DELETE SET NULL, variant_id uuid REFERENCES product_variants(id) ON DELETE SET NULL, policy_id uuid REFERENCES warranty_policies(id) ON DELETE SET NULL, issue text NOT NULL, status text NOT NULL DEFAULT 'Submitted' CHECK(status IN ('Submitted','Under Review','Approved','Rejected','In Repair','Ready for Collection','Resolved','Cancelled')), warranty_status text NOT NULL DEFAULT 'Pending' CHECK(warranty_status IN ('Pending','Covered','Not Covered','Goodwill')), estimated_cost numeric(18,2) NOT NULL DEFAULT 0 CHECK(estimated_cost>=0), approved_cost numeric(18,2) NOT NULL DEFAULT 0 CHECK(approved_cost>=0), resolution text NOT NULL DEFAULT '', received_at timestamptz, resolved_at timestamptz, created_by uuid REFERENCES users(id) ON DELETE SET NULL, assigned_to uuid REFERENCES users(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_warranty_claims_status ON warranty_claims(status,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_warranty_claims_customer ON warranty_claims(customer_id,created_at DESC);
CREATE TABLE IF NOT EXISTS repair_jobs(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), job_no text UNIQUE NOT NULL, claim_id uuid NOT NULL UNIQUE REFERENCES warranty_claims(id) ON DELETE CASCADE, technician_id uuid REFERENCES users(id) ON DELETE SET NULL, status text NOT NULL DEFAULT 'Queued' CHECK(status IN ('Queued','Diagnosing','Repairing','Awaiting Parts','Quality Check','Completed','Cancelled')), diagnosis text NOT NULL DEFAULT '', work_done text NOT NULL DEFAULT '', parts_used jsonb NOT NULL DEFAULT '[]'::jsonb, labor_cost numeric(18,2) NOT NULL DEFAULT 0 CHECK(labor_cost>=0), parts_cost numeric(18,2) NOT NULL DEFAULT 0 CHECK(parts_cost>=0), started_at timestamptz, completed_at timestamptz, notes text NOT NULL DEFAULT '', created_by uuid REFERENCES users(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS warranty_events(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), claim_id uuid NOT NULL REFERENCES warranty_claims(id) ON DELETE CASCADE, status text NOT NULL, note text NOT NULL DEFAULT '', actor_id uuid REFERENCES users(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_warranty_events_claim ON warranty_events(claim_id,created_at);

-- External repair partner management and repair tracking
CREATE TABLE IF NOT EXISTS repair_partners(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 name text NOT NULL,
 partner_type text NOT NULL DEFAULT 'Repair Centre' CHECK(partner_type IN ('Repair Centre','Technician','Authorized Service Centre')),
 phone text NOT NULL DEFAULT '', email text NOT NULL DEFAULT '', address text NOT NULL DEFAULT '', service_area text NOT NULL DEFAULT '',
 default_labor_cost numeric(18,2) NOT NULL DEFAULT 0 CHECK(default_labor_cost>=0),
 status text NOT NULL DEFAULT 'Active' CHECK(status IN ('Active','Suspended')),
 notes text NOT NULL DEFAULT '', created_by uuid REFERENCES users(id) ON DELETE SET NULL,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE repair_jobs ADD COLUMN IF NOT EXISTS partner_id uuid;
ALTER TABLE repair_jobs ADD COLUMN IF NOT EXISTS item_description text NOT NULL DEFAULT '';
ALTER TABLE repair_jobs ADD COLUMN IF NOT EXISTS repair_location text NOT NULL DEFAULT '';
ALTER TABLE repair_jobs ADD COLUMN IF NOT EXISTS expected_return_at timestamptz;
ALTER TABLE repair_jobs ADD COLUMN IF NOT EXISTS external_reference text NOT NULL DEFAULT '';
ALTER TABLE repair_jobs ADD COLUMN IF NOT EXISTS partner_cost numeric(18,2) NOT NULL DEFAULT 0 CHECK(partner_cost>=0);
DO $$ BEGIN ALTER TABLE repair_jobs ADD CONSTRAINT repair_jobs_partner_fk FOREIGN KEY(partner_id) REFERENCES repair_partners(id) ON DELETE SET NULL; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
CREATE INDEX IF NOT EXISTS idx_repair_jobs_partner ON repair_jobs(partner_id,status,created_at DESC);

ALTER TABLE warranty_claims ADD COLUMN IF NOT EXISTS coverage_starts_at timestamptz;
ALTER TABLE warranty_claims ADD COLUMN IF NOT EXISTS coverage_ends_at timestamptz;
ALTER TABLE warranty_claims ADD COLUMN IF NOT EXISTS eligibility_reason text NOT NULL DEFAULT '';
ALTER TABLE warranty_claims ADD COLUMN IF NOT EXISTS prior_serial_status text;
ALTER TABLE warranty_claims ADD COLUMN IF NOT EXISTS prior_serial_location_id uuid REFERENCES inventory_locations(id) ON DELETE SET NULL;
ALTER TABLE warranty_claims ADD COLUMN IF NOT EXISTS collected_at timestamptz;
ALTER TABLE warranty_claims ADD COLUMN IF NOT EXISTS collection_notes text NOT NULL DEFAULT '';
CREATE INDEX IF NOT EXISTS idx_warranty_claims_serial_active ON warranty_claims(serialized_unit_id,status) WHERE serialized_unit_id IS NOT NULL AND status IN ('Submitted','Under Review','Approved','In Repair','Ready for Collection');
CREATE INDEX IF NOT EXISTS idx_warranty_active_issue_serial ON warranty_claims(serialized_unit_id,lower(trim(issue)),status) WHERE serialized_unit_id IS NOT NULL AND status IN ('Submitted','Under Review','Approved','In Repair','Ready for Collection');
CREATE TABLE IF NOT EXISTS warranty_part_usage(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),claim_id uuid NOT NULL REFERENCES warranty_claims(id) ON DELETE CASCADE,repair_job_id uuid NOT NULL REFERENCES repair_jobs(id) ON DELETE CASCADE,variant_id uuid NOT NULL REFERENCES product_variants(id) ON DELETE RESTRICT,location_id uuid NOT NULL REFERENCES inventory_locations(id) ON DELETE RESTRICT,quantity numeric(18,3) NOT NULL CHECK(quantity>0),unit_cost numeric(18,2) NOT NULL DEFAULT 0 CHECK(unit_cost>=0),reason text NOT NULL DEFAULT '',created_by uuid REFERENCES users(id) ON DELETE SET NULL,created_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS idx_warranty_part_usage_claim ON warranty_part_usage(claim_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_warranty_part_usage_job ON warranty_part_usage(repair_job_id,created_at DESC);
