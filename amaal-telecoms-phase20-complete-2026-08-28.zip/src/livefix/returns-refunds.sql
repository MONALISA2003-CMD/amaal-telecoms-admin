-- Returns & Refunds
CREATE TABLE IF NOT EXISTS return_requests(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), return_no text UNIQUE NOT NULL, customer_id uuid REFERENCES customers(id) ON DELETE SET NULL, order_id uuid REFERENCES orders(id) ON DELETE SET NULL, sale_id uuid REFERENCES sales(id) ON DELETE SET NULL, location_id uuid REFERENCES inventory_locations(id) ON DELETE SET NULL, status text NOT NULL DEFAULT 'Requested' CHECK(status IN ('Requested','Approved','Rejected','Received','Inspected','Refund Pending','Refunded','Restocked','Cancelled')), reason text NOT NULL, notes text NOT NULL DEFAULT '', refund_method text NOT NULL DEFAULT 'Original Payment', refund_amount numeric(18,2) NOT NULL DEFAULT 0 CHECK(refund_amount>=0), requested_by uuid REFERENCES users(id) ON DELETE SET NULL, approved_by uuid REFERENCES users(id) ON DELETE SET NULL, received_by uuid REFERENCES users(id) ON DELETE SET NULL, inspected_by uuid REFERENCES users(id) ON DELETE SET NULL, refunded_by uuid REFERENCES users(id) ON DELETE SET NULL, approved_at timestamptz, received_at timestamptz, inspected_at timestamptz, refunded_at timestamptz, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), CHECK(order_id IS NOT NULL OR sale_id IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS idx_returns_status ON return_requests(status,created_at DESC);
CREATE TABLE IF NOT EXISTS return_lines(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), return_id uuid NOT NULL REFERENCES return_requests(id) ON DELETE CASCADE, variant_id uuid NOT NULL REFERENCES product_variants(id) ON DELETE RESTRICT, order_line_id uuid REFERENCES order_lines(id) ON DELETE SET NULL, sale_line_id uuid REFERENCES sale_lines(id) ON DELETE SET NULL, serialized_unit_id uuid REFERENCES serialized_units(id) ON DELETE SET NULL, quantity numeric(18,3) NOT NULL CHECK(quantity>0), unit_price numeric(18,2) NOT NULL DEFAULT 0 CHECK(unit_price>=0), reason text NOT NULL DEFAULT '', condition text NOT NULL DEFAULT 'Unknown' CHECK(condition IN ('New','Good','Used','Damaged','Defective','Unknown')), disposition text NOT NULL DEFAULT 'Restock' CHECK(disposition IN ('Restock','Repair','Scrap','Return to Supplier','Quarantine')), refund_amount numeric(18,2) NOT NULL DEFAULT 0 CHECK(refund_amount>=0), restocked_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_return_lines_return ON return_lines(return_id);
CREATE TABLE IF NOT EXISTS refund_transactions(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), refund_no text UNIQUE NOT NULL, return_id uuid NOT NULL REFERENCES return_requests(id) ON DELETE RESTRICT, amount numeric(18,2) NOT NULL CHECK(amount>0), method text NOT NULL CHECK(method IN ('Cash','Mobile Money','Card','Bank Transfer','Original Payment','Store Credit','Other')), reference text NOT NULL DEFAULT '', status text NOT NULL DEFAULT 'Completed' CHECK(status IN ('Pending','Completed','Failed','Reversed')), processed_by uuid REFERENCES users(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS return_events(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), return_id uuid NOT NULL REFERENCES return_requests(id) ON DELETE CASCADE, status text NOT NULL, note text NOT NULL DEFAULT '', actor_id uuid REFERENCES users(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_return_events_return ON return_events(return_id,created_at);


-- Phase 5 safety: a physical serialized unit represents exactly one returned item.
DO $$ BEGIN
  ALTER TABLE return_lines ADD CONSTRAINT return_lines_serialized_qty_one CHECK (serialized_unit_id IS NULL OR quantity = 1);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
CREATE INDEX IF NOT EXISTS idx_return_lines_serialized_unit ON return_lines(serialized_unit_id) WHERE serialized_unit_id IS NOT NULL;
