import Link from 'next/link';
import SiteHeader from '../../../components/SiteHeader';
import SiteFooter from '../../../components/SiteFooter';
import AddToBag from '../../../components/AddToBag';
import ProductGallery from '../../../components/ProductGallery';
import { getCatalog, image, price } from '../../../lib/catalog';
import { featuredProducts, newProducts, weeklyDeals, type HomeProduct } from '../../../lib/homepage-data';

const curated = [...featuredProducts, ...newProducts, ...weeklyDeals];
function ugx(value:number){return value ? new Intl.NumberFormat('en-UG',{style:'currency',currency:'UGX',maximumFractionDigits:0}).format(value) : 'Price on request'}

function CuratedDetail({p}:{p:HomeProduct}){
  return <main><SiteHeader/><section className="section product-detail"><div className="detail-image"><ProductGallery images={p.images} label={p.name}/></div><div className="detail-copy"><p className="eyebrow">{p.brand} · {p.eyebrow}</p><h1>{p.name}</h1><div className="detail-price">{ugx(p.price)}</div><p className="detail-note">{p.description}</p><div className="quick-specs">{p.quickDetails.map(x=><span key={x}>{x}</span>)}</div>{p.price>0?<AddToBag id={p.slug} name={p.name} price={ugx(p.price)}/>:<Link className="button gold" href="/contact">Enquire about this product</Link>}<div className="detail-trust"><span>Genuine product</span><span>Warranty support</span><span>Reliable delivery</span></div></div></section><section className="section product-detail-more"><p className="eyebrow">PRODUCT INFORMATION</p><h2>Everything you need to know.</h2><p>Full specifications, availability, delivery and warranty information can be expanded here as Amaal receives and publishes the official product asset and catalogue record.</p></section><SiteFooter/></main>
}

export default async function ProductPage({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const local=curated.find(x=>x.slug===slug);if(local)return <CuratedDetail p={local}/>;const catalog=await getCatalog();const p=(catalog?.products??[]).find(x=>(x.slug??String(x.id))===slug);if(!p)return <main><SiteHeader/><section className="section empty"><h1>Product not found.</h1><Link href="/shop">Return to shop</Link></section><SiteFooter/></main>;const formatted=price(p);return <main><SiteHeader/><section className="section product-detail"><div className="detail-image">{image(p)?<img src={image(p)} alt={p.name}/>:<div className="detail-placeholder"><span>AMAAL</span><strong>PRODUCT PHOTO</strong></div>}</div><div className="detail-copy"><p className="eyebrow">{p.brand_name??'AMAAL'}</p><h1>{p.name}</h1>{formatted&&<div className="detail-price">{formatted}</div>}<p className="detail-note">{p.description||p.short_description||'Genuine product from a trusted brand. Delivery and warranty details are confirmed through Amaal.'}</p>{formatted?<AddToBag id={String(p.id)} name={p.name} price={formatted}/>:<Link className="button gold" href="/contact">Enquire about this product</Link>}<div className="detail-trust"><span>Genuine product</span><span>Warranty support</span><span>Reliable delivery</span></div></div></section><SiteFooter/></main>}
